/**
 * CortxGPT Central Store
 * localStorage-based reactive store for support tickets, user registrations, and live stats
 */

// ==================== TYPES ====================

export interface SupportTicket {
  id: string;
  ticketNo: string;
  userId: string;
  userName: string;
  userEmail: string;
  userRole: "Free" | "Pro" | "VIP Premium";
  queuePosition: number;
  status: "waiting" | "connecting" | "connected" | "closed";
  messages: TicketMessage[];
  createdAt: string;
  connectedAt?: string;
  closedAt?: string;
  assignedAdmin?: string;
  priority: "normal" | "vip";
  isOnline: boolean;
}

export interface TicketMessage {
  id: string;
  text: string;
  sender: "user" | "admin" | "system";
  time: string;
}

export interface RegisteredUser {
  id: string;
  name: string;
  email: string;
  password: string;
  createdAt: string;
  provider: "email" | "google";
  role: "Free" | "Pro" | "VIP Premium";
  status: "active" | "passive" | "banned" | "pending";
  verified: boolean;
  ip: string;
  credits: number;
  dailyCredits: number;
  lastActive: string;
  firstLogin: string;
  avatar?: string;
  isVip: boolean;
  vipExpiry?: string;
}

export interface AdminNotification {
  id: string;
  type: "new_user" | "support_request" | "vip_purchase" | "system_alert" | "credit_load";
  title: string;
  message: string;
  time: string;
  read: boolean;
  userId?: string;
}

export interface LiveStats {
  totalUsers: number;
  activeUsers: number;
  todayRegistrations: number;
  premiumUsers: number;
  vipUsers: number;
  adminCount: number;
  pendingSupport: number;
  onlineUsers: number;
  chattingUsers: number;
  activeSupportSessions: number;
  activeAiRequests: number;
  totalCreditsUsed: number;
  todayCreditsUsed: number;
  totalCreditsGiven: number;
  vipCreditsUsed: number;
  dailyCreditStats: number[];
  dailyUserStats: number[];
  dailyRegistrationStats: number[];
}

// ==================== STORAGE KEYS ====================

const KEYS = {
  TICKETS: "cortxgpt_support_tickets",
  USERS: "cortxgpt_users",
  NOTIFICATIONS: "cortxgpt_admin_notifications",
  STATS: "cortxgpt_live_stats",
  CURRENT_TICKET: "cortxgpt_current_ticket",
};

// ==================== EVENT SYSTEM ====================

type StoreEvent = "tickets_updated" | "users_updated" | "notifications_updated" | "stats_updated";
const listeners: Record<string, Function[]> = {};

export function onStoreChange(event: StoreEvent, callback: Function) {
  if (!listeners[event]) listeners[event] = [];
  listeners[event].push(callback);
  return () => {
    listeners[event] = listeners[event].filter((cb) => cb !== callback);
  };
}

function emit(event: StoreEvent) {
  (listeners[event] || []).forEach((cb) => cb());
  // Also dispatch a custom DOM event for cross-component reactivity
  window.dispatchEvent(new CustomEvent(`cortxgpt_${event}`));
}

// ==================== HELPERS ====================

function get<T>(key: string, fallback: T): T {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : fallback;
  } catch {
    return fallback;
  }
}

function set(key: string, value: any) {
  localStorage.setItem(key, JSON.stringify(value));
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function generateTicketNo() {
  const num = Math.floor(10000 + Math.random() * 90000);
  return `TK-${num}`;
}

function generateIp() {
  return `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
}

function now() {
  return new Date().toISOString();
}

function timeStr() {
  return new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
}

// ==================== SUPPORT TICKETS ====================

export function getTickets(): SupportTicket[] {
  return get<SupportTicket[]>(KEYS.TICKETS, []);
}

export function getWaitingTickets(): SupportTicket[] {
  return getTickets().filter((t) => t.status === "waiting" || t.status === "connecting");
}

export function getActiveTickets(): SupportTicket[] {
  return getTickets().filter((t) => t.status === "connected");
}

export function getClosedTickets(): SupportTicket[] {
  return getTickets().filter((t) => t.status === "closed");
}

export function createTicket(userName: string, userEmail: string, firstMessage: string, userRole: "Free" | "Pro" | "VIP Premium" = "Free"): SupportTicket {
  const tickets = getTickets();
  const waitingCount = tickets.filter((t) => t.status === "waiting" || t.status === "connecting").length;
  const isVip = userRole === "VIP Premium";

  const ticket: SupportTicket = {
    id: generateId(),
    ticketNo: generateTicketNo(),
    userId: generateId(),
    userName,
    userEmail,
    userRole,
    queuePosition: isVip ? 1 : waitingCount + 1,
    status: "waiting",
    messages: [
      { id: generateId(), text: firstMessage, sender: "user", time: timeStr() },
      { id: generateId(), text: "Destek talebiniz alındı. Sıraya alındınız, lütfen bekleyin.", sender: "system", time: timeStr() },
    ],
    createdAt: now(),
    priority: isVip ? "vip" : "normal",
    isOnline: true,
  };

  // VIP users go to front of queue, reorder others
  if (isVip) {
    const waiting = tickets.filter((t) => t.status === "waiting" || t.status === "connecting");
    waiting.forEach((t) => { t.queuePosition += 1; });
  }

  tickets.unshift(ticket);
  set(KEYS.TICKETS, tickets);
  set(KEYS.CURRENT_TICKET, ticket.id);

  // Add admin notification
  addNotification({
    type: "support_request",
    title: "Yeni Destek Talebi",
    message: `${userName} (${userRole}) destek talep etti: "${firstMessage.slice(0, 50)}..."`,
    userId: ticket.userId,
  });

  // Update stats
  updateStat("pendingSupport", (s) => s + 1);

  emit("tickets_updated");
  return ticket;
}

export function addMessageToTicket(ticketId: string, text: string, sender: "user" | "admin" | "system") {
  const tickets = getTickets();
  const ticket = tickets.find((t) => t.id === ticketId);
  if (!ticket) return;
  ticket.messages.push({ id: generateId(), text, sender, time: timeStr() });
  set(KEYS.TICKETS, tickets);
  emit("tickets_updated");
}

export function connectToTicket(ticketId: string, adminName: string) {
  const tickets = getTickets();
  const ticket = tickets.find((t) => t.id === ticketId);
  if (!ticket) return;

  ticket.status = "connected";
  ticket.connectedAt = now();
  ticket.assignedAdmin = adminName;
  ticket.messages.push({
    id: generateId(),
    text: `${adminName} destek görüşmesine bağlandı. Size nasıl yardımcı olabilirim?`,
    sender: "admin",
    time: timeStr(),
  });

  // Reorder remaining queue
  const waiting = tickets.filter((t) => t.status === "waiting");
  waiting.sort((a, b) => {
    if (a.priority === "vip" && b.priority !== "vip") return -1;
    if (b.priority === "vip" && a.priority !== "vip") return 1;
    return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
  });
  waiting.forEach((t, i) => { t.queuePosition = i + 1; });

  set(KEYS.TICKETS, tickets);
  updateStat("pendingSupport", (s) => Math.max(0, s - 1));
  updateStat("activeSupportSessions", (s) => s + 1);
  emit("tickets_updated");
}

export function closeTicket(ticketId: string) {
  const tickets = getTickets();
  const ticket = tickets.find((t) => t.id === ticketId);
  if (!ticket) return;
  ticket.status = "closed";
  ticket.closedAt = now();
  ticket.messages.push({ id: generateId(), text: "Destek görüşmesi sonlandırıldı. İyi günler!", sender: "system", time: timeStr() });
  set(KEYS.TICKETS, tickets);
  updateStat("activeSupportSessions", (s) => Math.max(0, s - 1));
  emit("tickets_updated");
}

export function cancelTicket(ticketId: string) {
  const tickets = getTickets();
  const ticket = tickets.find((t) => t.id === ticketId);
  if (!ticket) return;
  const wasWaiting = ticket.status === "waiting" || ticket.status === "connecting";
  ticket.status = "closed";
  ticket.closedAt = now();
  ticket.isOnline = false;

  const waiting = tickets.filter((t) => t.status === "waiting" && t.id !== ticketId);
  waiting.forEach((t, i) => { t.queuePosition = i + 1; });

  set(KEYS.TICKETS, tickets);
  if (wasWaiting) updateStat("pendingSupport", (s) => Math.max(0, s - 1));
  emit("tickets_updated");
}

export function getCurrentTicketId(): string | null {
  return localStorage.getItem(KEYS.CURRENT_TICKET) || null;
}

export function getTicketById(id: string): SupportTicket | null {
  return getTickets().find((t) => t.id === id) || null;
}

// ==================== USERS ====================

export function getRegisteredUsers(): RegisteredUser[] {
  return get<RegisteredUser[]>(KEYS.USERS, []);
}

export function registerUser(data: { name: string; email: string; password: string; provider?: "email" | "google" }): RegisteredUser {
  const users = getRegisteredUsers();
  const user: RegisteredUser = {
    id: generateId(),
    name: data.name,
    email: data.email,
    password: data.password,
    createdAt: now(),
    provider: data.provider || "email",
    role: "Free",
    status: "active",
    verified: data.provider === "google",
    ip: generateIp(),
    credits: 100,
    dailyCredits: 50,
    lastActive: now(),
    firstLogin: now(),
    isVip: false,
  };

  users.unshift(user);
  set(KEYS.USERS, users);

  // Notification
  addNotification({
    type: "new_user",
    title: "Yeni Kullanıcı Kaydı",
    message: `${data.name} (${data.email}) ${data.provider === "google" ? "Google ile" : "e-posta ile"} kayıt oldu.`,
    userId: user.id,
  });

  // Update stats
  updateStat("totalUsers", (s) => s + 1);
  updateStat("todayRegistrations", (s) => s + 1);

  emit("users_updated");
  return user;
}

export function updateUser(userId: string, updates: Partial<RegisteredUser>) {
  const users = getRegisteredUsers();
  const idx = users.findIndex((u) => u.id === userId);
  if (idx === -1) return;
  users[idx] = { ...users[idx], ...updates };
  set(KEYS.USERS, users);
  emit("users_updated");
}

export function banUser(userId: string) {
  updateUser(userId, { status: "banned" });
  const user = getRegisteredUsers().find((u) => u.id === userId);
  if (user) {
    addNotification({
      type: "system_alert",
      title: "Kullanıcı Banlandı",
      message: `${user.name} (${user.email}) banlandı.`,
      userId,
    });
  }
}

export function giveVip(userId: string) {
  const expiry = new Date();
  expiry.setDate(expiry.getDate() + 30);
  updateUser(userId, {
    isVip: true,
    role: "VIP Premium",
    credits: 3000,
    dailyCredits: 500,
    vipExpiry: expiry.toISOString(),
  });
  updateStat("vipUsers", (s) => s + 1);
  const user = getRegisteredUsers().find((u) => u.id === userId);
  if (user) {
    addNotification({
      type: "vip_purchase",
      title: "VIP Üyelik Verildi",
      message: `${user.name} VIP Premium üyelik aldı.`,
      userId,
    });
  }
}

export function addCredits(userId: string, amount: number) {
  const users = getRegisteredUsers();
  const user = users.find((u) => u.id === userId);
  if (!user) return;
  user.credits += amount;
  set(KEYS.USERS, users);
  updateStat("totalCreditsGiven", (s) => s + amount);
  addNotification({
    type: "credit_load",
    title: "Kredi Yüklendi",
    message: `${user.name}'e ${amount} kredi yüklendi. Toplam: ${user.credits}`,
    userId,
  });
  emit("users_updated");
}

// ==================== NOTIFICATIONS ====================

export function getNotifications(): AdminNotification[] {
  return get<AdminNotification[]>(KEYS.NOTIFICATIONS, []);
}

export function getUnreadCount(): number {
  return getNotifications().filter((n) => !n.read).length;
}

export function addNotification(data: Omit<AdminNotification, "id" | "time" | "read">) {
  const notifs = getNotifications();
  notifs.unshift({
    ...data,
    id: generateId(),
    time: now(),
    read: false,
  });
  // Keep max 100
  if (notifs.length > 100) notifs.length = 100;
  set(KEYS.NOTIFICATIONS, notifs);
  emit("notifications_updated");
}

export function markAllRead() {
  const notifs = getNotifications();
  notifs.forEach((n) => { n.read = true; });
  set(KEYS.NOTIFICATIONS, notifs);
  emit("notifications_updated");
}

export function clearNotifications() {
  set(KEYS.NOTIFICATIONS, []);
  emit("notifications_updated");
}

// ==================== LIVE STATS ====================

function getDefaultStats(): LiveStats {
  return {
    totalUsers: getRegisteredUsers().length || 12847,
    activeUsers: 3421,
    todayRegistrations: 147,
    premiumUsers: 1256,
    vipUsers: 342,
    adminCount: 8,
    pendingSupport: getWaitingTickets().length,
    onlineUsers: Math.floor(800 + Math.random() * 400),
    chattingUsers: Math.floor(120 + Math.random() * 80),
    activeSupportSessions: getActiveTickets().length,
    activeAiRequests: Math.floor(40 + Math.random() * 30),
    totalCreditsUsed: 89340,
    todayCreditsUsed: 4520,
    totalCreditsGiven: 245000,
    vipCreditsUsed: 32100,
    dailyCreditStats: [3200, 4100, 3800, 4500, 4200, 3900, 4520],
    dailyUserStats: [2800, 3100, 2900, 3400, 3200, 3000, 3421],
    dailyRegistrationStats: [120, 135, 128, 142, 138, 130, 147],
  };
}

export function getStats(): LiveStats {
  const stored = get<LiveStats | null>(KEYS.STATS, null);
  if (!stored) {
    const defaults = getDefaultStats();
    set(KEYS.STATS, defaults);
    return defaults;
  }
  return stored;
}

export function updateStat(key: keyof LiveStats, updater: (current: number) => number) {
  const stats = getStats();
  const val = stats[key];
  if (typeof val === "number") {
    (stats as any)[key] = updater(val);
  }
  set(KEYS.STATS, stats);
  emit("stats_updated");
}

export function setStats(updates: Partial<LiveStats>) {
  const stats = getStats();
  Object.assign(stats, updates);
  set(KEYS.STATS, stats);
  emit("stats_updated");
}

// Simulate live fluctuations
export function startLiveStatSimulation() {
  const interval = setInterval(() => {
    const stats = getStats();
    // Small random fluctuations
    stats.onlineUsers = Math.max(500, stats.onlineUsers + Math.floor(Math.random() * 20 - 10));
    stats.chattingUsers = Math.max(50, stats.chattingUsers + Math.floor(Math.random() * 10 - 5));
    stats.activeAiRequests = Math.max(10, stats.activeAiRequests + Math.floor(Math.random() * 8 - 4));
    stats.todayCreditsUsed += Math.floor(Math.random() * 15);
    stats.totalCreditsUsed += Math.floor(Math.random() * 15);
    set(KEYS.STATS, stats);
    emit("stats_updated");
  }, 3000);
  return () => clearInterval(interval);
}

// ==================== HOOKS HELPER ====================

export function useStoreListener(event: StoreEvent, callback: () => void) {
  // This is a helper - use it inside useEffect in components
  const handler = () => callback();
  window.addEventListener(`cortxgpt_${event}`, handler);
  return () => window.removeEventListener(`cortxgpt_${event}`, handler);
}
