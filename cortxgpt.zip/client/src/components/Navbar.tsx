/*
 * CortxGPT Navbar
 * Design: Cyber Noir - Glassmorphism nav bar with neon accents
 * Font: Space Grotesk for brand, Inter for links
 */
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663469047697/7PMHtqMX2cLBqPHn4Fvif7/ai-brain-logo-UPKum59kVPznZdwMyoKdyZ.webp";

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [location] = useLocation();

  const navLinks = [
    { href: "/", label: "Ana Sayfa" },
    { href: "/#features", label: "Özellikler" },
    { href: "/#pricing", label: "Fiyatlandırma" },
    { href: "/#about", label: "Hakkımızda" },
    { href: "/chat", label: "Sohbet" },
  ];

  const scrollToSection = (href: string) => {
    setMobileOpen(false);
    if (href.startsWith("/#")) {
      const id = href.replace("/#", "");
      if (location === "/") {
        const el = document.getElementById(id);
        el?.scrollIntoView({ behavior: "smooth" });
      } else {
        window.location.href = href;
      }
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-card border-b border-white/5">
      <div className="container flex items-center justify-between h-16 lg:h-18">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5 group">
          <img src={LOGO_URL} alt="CortxGPT" className="w-8 h-8 lg:w-9 lg:h-9 transition-transform group-hover:scale-110" />
          <span className="text-xl lg:text-2xl font-bold font-[var(--font-heading)] gradient-text">
            CortxGPT
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-1">
          {navLinks.map((link) => (
            link.href.startsWith("/#") ? (
              <button
                key={link.href}
                onClick={() => scrollToSection(link.href)}
                className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-white/5"
              >
                {link.label}
              </button>
            ) : (
              <Link
                key={link.href}
                href={link.href}
                className={`px-4 py-2 text-sm rounded-lg transition-colors ${
                  location === link.href
                    ? "text-neon-blue bg-neon-blue/10"
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                }`}
              >
                {link.label}
              </Link>
            )
          ))}
        </div>

        {/* Desktop CTA */}
        <div className="hidden lg:flex items-center gap-3">
          <Link href="/auth" className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            Giriş Yap
          </Link>
          <Link href="/chat" className="gradient-btn px-5 py-2.5 text-sm font-semibold text-white rounded-lg">
            Hemen Başla
          </Link>
        </div>

        {/* Mobile Toggle */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="lg:hidden p-2 text-muted-foreground hover:text-foreground"
        >
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden glass-card border-t border-white/5 overflow-hidden"
          >
            <div className="container py-4 flex flex-col gap-1">
              {navLinks.map((link) => (
                link.href.startsWith("/#") ? (
                  <button
                    key={link.href}
                    onClick={() => scrollToSection(link.href)}
                    className="px-4 py-3 text-sm text-muted-foreground hover:text-foreground text-left rounded-lg hover:bg-white/5"
                  >
                    {link.label}
                  </button>
                ) : (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className="px-4 py-3 text-sm text-muted-foreground hover:text-foreground rounded-lg hover:bg-white/5"
                  >
                    {link.label}
                  </Link>
                )
              ))}
              <div className="flex gap-3 mt-3 px-4">
                <Link href="/auth" onClick={() => setMobileOpen(false)} className="flex-1 text-center py-2.5 text-sm border border-white/10 rounded-lg text-muted-foreground hover:text-foreground">
                  Giriş Yap
                </Link>
                <Link href="/chat" onClick={() => setMobileOpen(false)} className="flex-1 text-center gradient-btn py-2.5 text-sm font-semibold text-white rounded-lg">
                  Hemen Başla
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
