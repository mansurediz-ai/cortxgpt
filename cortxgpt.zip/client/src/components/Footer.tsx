/*
 * CortxGPT Footer
 * Design: Cyber Noir - Dark footer with neon accents and glassmorphism
 */
import { Link } from "wouter";
import { Brain, Github, Twitter, Linkedin, Instagram, Mail, MapPin, Phone } from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663469047697/7PMHtqMX2cLBqPHn4Fvif7/ai-brain-logo-UPKum59kVPznZdwMyoKdyZ.webp";

export default function Footer() {
  const quickLinks = [
    { label: "Ana Sayfa", href: "/" },
    { label: "Sohbet", href: "/chat" },
    { label: "Özellikler", href: "/#features" },
    { label: "Fiyatlandırma", href: "/#pricing" },
    { label: "Hakkımızda", href: "/#about" },
  ];

  const supportLinks = [
    { label: "Yardım Merkezi", href: "#" },
    { label: "Gizlilik Politikası", href: "#" },
    { label: "Kullanım Koşulları", href: "#" },
    { label: "SSS", href: "#" },
    { label: "İletişim", href: "#" },
  ];

  return (
    <footer className="relative border-t border-white/5 bg-[oklch(0.08_0.015_270)]">
      {/* Glow line */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-px bg-gradient-to-r from-transparent via-neon-blue/50 to-transparent" />

      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <img src={LOGO_URL} alt="CortxGPT" className="w-8 h-8" />
              <span className="text-xl font-bold font-[var(--font-heading)] gradient-text">CortxGPT</span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed mb-6">
              Yeni nesil yapay zeka platformu. Akıllı sohbet, hızlı cevaplar ve gelişmiş AI araçları ile geleceğin teknolojisini bugün deneyimleyin.
            </p>
            <div className="flex gap-3">
              {[
                { icon: Twitter, href: "#" },
                { icon: Github, href: "#" },
                { icon: Linkedin, href: "#" },
                { icon: Instagram, href: "#" },
              ].map((social, i) => (
                <a
                  key={i}
                  href={social.href}
                  className="w-9 h-9 rounded-lg glass-card flex items-center justify-center text-muted-foreground hover:text-neon-blue hover:border-neon-blue/30 transition-all"
                >
                  <social.icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-4 font-[var(--font-heading)]">Hızlı Linkler</h4>
            <ul className="space-y-2.5">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <Link href={link.href} className="text-sm text-muted-foreground hover:text-neon-blue transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-4 font-[var(--font-heading)]">Destek</h4>
            <ul className="space-y-2.5">
              {supportLinks.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-sm text-muted-foreground hover:text-neon-blue transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-4 font-[var(--font-heading)]">İletişim</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2.5 text-sm text-muted-foreground">
                <Mail size={15} className="text-neon-blue shrink-0" />
                <span>destek@cortxgpt.com</span>
              </li>
              <li className="flex items-center gap-2.5 text-sm text-muted-foreground">
                <Phone size={15} className="text-neon-blue shrink-0" />
                <span>+90 (212) 555 0199</span>
              </li>
              <li className="flex items-start gap-2.5 text-sm text-muted-foreground">
                <MapPin size={15} className="text-neon-blue shrink-0 mt-0.5" />
                <span>İstanbul, Türkiye</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-12 pt-6 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} CortxGPT. Tüm hakları saklıdır.
          </p>
          <p className="text-xs text-muted-foreground">
            Yapay zeka ile güçlendirilmiş platform
          </p>
        </div>
      </div>
    </footer>
  );
}
