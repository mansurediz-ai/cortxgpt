/*
 * CortxGPT Advanced Live Support Widget
 * Features: Queue system, ticket tracking, waiting screen, real-time chat
 */
import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, Minus, Loader2, Clock, Users } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import {
  createTicket, addMessageToTicket, cancelTicket,
  getCurrentTicketId, getTicketById,
  type SupportTicket, type TicketMessage
} from "@/lib/store";

type Phase = "idle" | "waiting" | "connected";

export default function LiveSupport() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [input, setInput] = useState("");
  const [unread, setUnread] = useState(1);
  const [phase, setPhase] = useState<Phase>("idle");
  const [ticket, setTicket] = useState<SupportTicket | null>(null);
  const [messages, setMessages] = useState<TicketMessage[]>([
    { id: "welcome", text: "Merhaba! CortxGPT destek ekibine hoş geldiniz. Mesajınızı yazın, sizi sıraya alalım.", sender: "system", time: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }) }
  ]);
  const [waitTime, setWaitTime] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [location] = useLocation();

  // Restore ticket on mount
  useEffect(() => {
    const tid = getCurrentTicketId();
    if (tid) {
      const t = getTicketById(tid);
      if (t && t.status !== "closed") {
        setTicket(t);
        setMessages(t.messages);
        setPhase(t.status === "connected" ? "connected" : "waiting");
      }
    }
  }, []);

  // Poll ticket updates
  useEffect(() => {
    if (!ticket) return;
    const iv = setInterval(() => {
      const t = getTicketById(ticket.id);
      if (!t) return;
      setTicket(t);
      setMessages(t.messages);
      if (t.status === "connected" && phase !== "connected") {
        setPhase("connected");
        setUnread((p) => p + 1);
      }
      if (t.status === "closed") {
        setPhase("idle");
        setTicket(null);
        setMessages([{ id: "closed", text: "Destek görüşmesi sonlandırıldı. Yeni bir talep oluşturabilirsiniz.", sender: "system", time: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }) }]);
      }
    }, 1500);
    return () => clearInterval(iv);
  }, [ticket, phase]);

  // Wait timer
  useEffect(() => {
    if (phase !== "waiting") return;
    const iv = setInterval(() => setWaitTime((p) => p + 1), 1000);
    return () => clearInterval(iv);
  }, [phase]);

  useEffect(() => {
    if (isOpen) messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isOpen]);

  if (location === "/admin-panel" || location === "/admin" || location === "/chat") return null;

  const sendMessage = () => {
    if (!input.trim()) return;
    const text = input.trim();
    setInput("");

    if (phase === "idle" && !ticket) {
      // Create new ticket
      const currentUser = (() => { try { return JSON.parse(localStorage.getItem("cortxgpt_current_user") || "{}"); } catch { return {}; } })();
      const name = currentUser.name || "Misafir";
      const email = currentUser.email || "misafir@cortxgpt.com";
      const t = createTicket(name, email, text);
      setTicket(t);
      setMessages(t.messages);
      setPhase("waiting");
      setWaitTime(0);
    } else if (ticket) {
      addMessageToTicket(ticket.id, text, "user");
      const updated = getTicketById(ticket.id);
      if (updated) setMessages(updated.messages);
    }
  };

  const handleClose = () => {
    if (ticket && (phase === "waiting" || phase === "connected")) {
      cancelTicket(ticket.id);
      setTicket(null);
      setPhase("idle");
      setMessages([{ id: "cancelled", text: "Destek talebi iptal edildi. Yeni bir talep oluşturabilirsiniz.", sender: "system", time: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }) }]);
    }
    setIsOpen(false);
  };

  const formatWait = (s: number) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;

  return (
    <>
      {/* Floating Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}
            onClick={() => { setIsOpen(true); setUnread(0); }}
            className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full gradient-btn flex items-center justify-center shadow-lg hover:shadow-neon-blue/30 transition-shadow"
          >
            <MessageCircle size={24} className="text-white" />
            {unread > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-[10px] text-white font-bold flex items-center justify-center">{unread}</span>
            )}
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 w-[380px] max-w-[calc(100vw-2rem)] rounded-2xl glass-card border border-white/10 overflow-hidden shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-white/5 bg-gradient-to-r from-neon-blue/10 to-neon-purple/10">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-9 h-9 rounded-full gradient-btn flex items-center justify-center"><MessageCircle size={16} className="text-white" /></div>
                  <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[oklch(0.15_0.02_270)] bg-green-500" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">CortxGPT Destek</p>
                  <p className="text-[11px] text-muted-foreground">
                    {phase === "waiting" ? "Sırada bekliyorsunuz..." : phase === "connected" ? "Bağlandı" : "Çevrimiçi"}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => setIsMinimized(!isMinimized)} className="p-1.5 rounded-lg hover:bg-white/5 text-muted-foreground"><Minus size={16} /></button>
                <button onClick={handleClose} className="p-1.5 rounded-lg hover:bg-white/5 text-muted-foreground"><X size={16} /></button>
              </div>
            </div>

            {!isMinimized && (
              <>
                {/* Waiting Screen */}
                {phase === "waiting" && ticket && (
                  <div className="p-5 text-center border-b border-white/5 bg-gradient-to-b from-neon-blue/5 to-transparent">
                    <div className="relative w-16 h-16 mx-auto mb-3">
                      <div className="absolute inset-0 rounded-full border-2 border-neon-blue/30 border-t-neon-blue animate-spin" />
                      <div className="absolute inset-2 rounded-full border-2 border-neon-purple/30 border-b-neon-purple animate-spin" style={{ animationDirection: "reverse", animationDuration: "1.5s" }} />
                      <div className="absolute inset-0 flex items-center justify-center"><Users size={20} className="text-neon-blue" /></div>
                    </div>
                    <p className="text-sm font-semibold text-foreground mb-1">Size uygun destek temsilcisi aranıyor</p>
                    <p className="text-xs text-muted-foreground mb-3">Lütfen bekleyin, sıraya alındınız</p>
                    <div className="flex items-center justify-center gap-4 text-xs">
                      <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5">
                        <Users size={12} className="text-neon-blue" />
                        <span className="text-muted-foreground">Sıra: <span className="text-neon-blue font-bold">#{ticket.queuePosition}</span></span>
                      </div>
                      <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5">
                        <Clock size={12} className="text-neon-purple" />
                        <span className="text-muted-foreground">Süre: <span className="text-neon-purple font-bold">{formatWait(waitTime)}</span></span>
                      </div>
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-3">Ticket: {ticket.ticketNo}</p>
                  </div>
                )}

                {/* Messages */}
                <div className="h-[280px] overflow-y-auto p-4 space-y-3 scrollbar-thin">
                  {messages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
                      <div className={`max-w-[80%] px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed ${
                        msg.sender === "user" ? "gradient-btn text-white rounded-br-md"
                        : msg.sender === "admin" ? "bg-neon-blue/10 border border-neon-blue/20 text-foreground rounded-bl-md"
                        : "bg-white/5 text-muted-foreground rounded-bl-md italic text-xs"
                      }`}>
                        {msg.sender === "admin" && <p className="text-[10px] text-neon-blue font-semibold mb-1">Admin Destek</p>}
                        <p>{msg.text}</p>
                        <p className={`text-[10px] mt-1 ${msg.sender === "user" ? "text-white/60" : "text-muted-foreground"}`}>{msg.time}</p>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <div className="p-3 border-t border-white/5">
                  <div className="flex items-center gap-2 bg-white/5 rounded-xl px-3 py-2">
                    <input
                      type="text" value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                      placeholder={phase === "idle" ? "Mesaj yazın, destek talebi oluşturulsun..." : "Mesajınızı yazın..."}
                      className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none"
                    />
                    <button onClick={sendMessage} disabled={!input.trim()} className="p-2 rounded-lg gradient-btn text-white disabled:opacity-30">
                      <Send size={14} />
                    </button>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
