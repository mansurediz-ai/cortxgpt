import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Shield, Lock, User, ArrowRight, AlertCircle, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663469047697/7PMHtqMX2cLBqPHn4Fvif7/ai-brain-logo-UPKum59kVPznZdwMyoKdyZ.webp";

const ADMIN_CREDENTIALS = {
  username: "admin",
  password: "cortxgpt123",
};

export default function AdminLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [, navigate] = useLocation();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!username.trim()) {
      setError("Kullanıcı adı gereklidir.");
      return;
    }
    if (!password.trim()) {
      setError("Şifre gereklidir.");
      return;
    }

    setLoading(true);

    setTimeout(() => {
      if (username !== ADMIN_CREDENTIALS.username) {
        setError("Kullanıcı adı bulunamadı. Bu alan sadece yetkili yöneticiler içindir.");
        setLoading(false);
        return;
      }
      if (password !== ADMIN_CREDENTIALS.password) {
        setError("Şifre yanlış. Lütfen tekrar deneyin.");
        setLoading(false);
        return;
      }

      // Save admin session
      localStorage.setItem("cortxgpt_admin_session", JSON.stringify({
        username,
        loggedInAt: new Date().toISOString(),
        isAdmin: true,
      }));

      toast.success("Admin girişi başarılı! Panele yönlendiriliyorsunuz...");
      setTimeout(() => navigate("/admin-panel"), 500);
      setLoading(false);
    }, 800);
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/3 left-1/3 w-80 h-80 rounded-full bg-neon-blue/6 blur-[150px]" />
        <div className="absolute bottom-1/3 right-1/3 w-80 h-80 rounded-full bg-neon-purple/6 blur-[150px]" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-sm mx-4 relative z-10"
      >
        {/* Logo */}
        <div className="flex items-center justify-center gap-2.5 mb-8">
          <img src={LOGO_URL} alt="CortxGPT" className="w-10 h-10" />
          <span className="text-2xl font-bold gradient-text font-[var(--font-heading)]">CortxGPT</span>
        </div>

        <div className="glass-card rounded-2xl p-7 border border-white/5">
          {/* Header */}
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center">
              <Shield size={20} className="text-red-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-[var(--font-heading)]">Admin Girişi</h2>
              <p className="text-xs text-muted-foreground">Yetkili erişim alanı</p>
            </div>
          </div>

          {/* Error */}
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-start gap-2.5 p-3 rounded-xl bg-red-500/10 border border-red-500/20 mb-5"
            >
              <AlertCircle size={16} className="text-red-400 shrink-0 mt-0.5" />
              <p className="text-sm text-red-400">{error}</p>
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block">Kullanıcı Adı</label>
              <div className="relative">
                <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => { setUsername(e.target.value); setError(""); }}
                  placeholder="Kullanıcı adınız"
                  autoComplete="off"
                  className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-neon-blue/50 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block">Şifre</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); setError(""); }}
                  placeholder="Şifreniz"
                  autoComplete="off"
                  className="w-full pl-10 pr-12 py-3 rounded-xl bg-white/5 border border-white/10 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-neon-blue/50 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full gradient-btn py-3 rounded-xl text-white font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {loading ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Doğrulanıyor...
                </>
              ) : (
                <>
                  Giriş Yap <ArrowRight size={16} />
                </>
              )}
            </button>
          </form>

          <div className="mt-5 pt-4 border-t border-white/5 text-center">
            <p className="text-[11px] text-muted-foreground">
              Bu alan sadece yetkili yöneticiler içindir. Yetkisiz erişim girişimleri kayıt altına alınır.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
