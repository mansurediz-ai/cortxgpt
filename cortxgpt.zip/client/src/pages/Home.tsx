import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  MessageSquare, Globe, Zap, Headphones, Shield, History,
  Image, Code, Check, Crown, Star, ArrowRight, Sparkles, Bot
} from "lucide-react";

const HERO_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663469047697/7PMHtqMX2cLBqPHn4Fvif7/hero-bg-LTLSe5FRsgr9KnynAj8E5U.webp";
const CHAT_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663469047697/7PMHtqMX2cLBqPHn4Fvif7/chat-illustration-DYTszjiESLhg3BTaTru2i5.webp";
const FEATURES_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663469047697/7PMHtqMX2cLBqPHn4Fvif7/features-abstract-Tzr5RHAhLMU4svngMCsK8P.webp";
const ABOUT_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663469047697/7PMHtqMX2cLBqPHn4Fvif7/about-section-WC3YXwuoMmTtX4VkgLV4U9.webp";

const fadeUp = { hidden: { opacity: 0, y: 30 }, visible: { opacity: 1, y: 0 } };

const features = [
  { icon: MessageSquare, title: "Yapay Zeka Sohbet", desc: "Gelişmiş dil modeli ile doğal ve akıcı sohbet deneyimi yaşayın." },
  { icon: Globe, title: "Çoklu Dil Desteği", desc: "50'den fazla dilde anlık çeviri ve sohbet imkanı." },
  { icon: Zap, title: "Hızlı Cevap Sistemi", desc: "Milisaniyeler içinde doğru ve kapsamlı yanıtlar alın." },
  { icon: Headphones, title: "Canlı Destek", desc: "7/24 canlı destek ekibiyle gerçek zamanlı yardım." },
  { icon: Shield, title: "Güvenli Kullanım", desc: "Uçtan uca şifreleme ile verileriniz her zaman güvende." },
  { icon: History, title: "Sohbet Kayıtları", desc: "Tüm geçmiş sohbetlerinize istediğiniz zaman erişin." },
  { icon: Image, title: "Görsel Üretme", desc: "Metin açıklamalarından yüksek kaliteli görseller oluşturun." },
  { icon: Code, title: "Kod Yazma Desteği", desc: "Birden fazla programlama dilinde kod yazma ve hata ayıklama." },
];

const plans = [
  {
    name: "Free",
    price: "₺0",
    period: "/ay",
    desc: "Başlangıç için ideal",
    icon: Sparkles,
    popular: false,
    features: ["Günlük 50 mesaj", "Temel AI modeli", "Sohbet geçmişi (7 gün)", "Topluluk desteği", "Tek dil desteği"],
    credits: "Günlük 100 kredi",
    cta: "Ücretsiz Başla",
  },
  {
    name: "Pro",
    price: "₺149",
    period: "/ay",
    desc: "Profesyoneller için",
    icon: Star,
    popular: true,
    features: ["Sınırsız mesaj", "Gelişmiş AI modeli", "Sınırsız sohbet geçmişi", "Öncelikli destek", "Çoklu dil desteği", "Görsel üretme", "Kod yazma desteği"],
    credits: "Günlük 300 kredi",
    cta: "Pro'ya Geç",
  },
  {
    name: "VIP Premium",
    price: "₺349",
    period: "/ay",
    desc: "En üst düzey deneyim",
    icon: Crown,
    popular: false,
    vip: true,
    features: ["Tüm Pro özellikleri", "3000 başlangıç kredisi", "Günlük 500 kredi", "VIP rozeti", "Öncelikli AI işlem hakkı", "Daha hızlı AI cevapları", "Özel API erişimi", "Birebir destek"],
    credits: "3000 başlangıç + günlük 500 kredi",
    cta: "VIP Ol",
  },
];

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navbar />

      {/* ===== HERO ===== */}
      <section className="relative min-h-screen flex items-center overflow-hidden pt-16">
        <div className="absolute inset-0">
          <img src={HERO_BG} alt="" className="w-full h-full object-cover opacity-40" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />
        </div>
        {/* Floating orbs */}
        <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-neon-blue/10 blur-[100px] animate-[float_8s_ease-in-out_infinite]" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full bg-neon-purple/10 blur-[120px] animate-[float_10s_ease-in-out_infinite_1s]" />

        <div className="container relative z-10 grid lg:grid-cols-2 gap-12 items-center py-20">
          <motion.div initial="hidden" animate="visible" variants={fadeUp} transition={{ duration: 0.7 }}>
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-card text-xs text-neon-blue mb-6">
              <Bot size={14} /> Yapay Zeka Platformu
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6 font-[var(--font-heading)]">
              <span className="gradient-text">CortxGPT</span> ile Yeni Nesil{" "}
              <span className="text-foreground">Yapay Zeka Deneyimi</span>
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed mb-8 max-w-lg">
              Akıllı sohbet, hızlı cevaplar, canlı destek ve gelişmiş AI araçları tek platformda.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link href="/chat" className="gradient-btn px-8 py-3.5 rounded-xl text-white font-semibold inline-flex items-center gap-2">
                Hemen Başla <ArrowRight size={18} />
              </Link>
              <Link href="/auth" className="px-8 py-3.5 rounded-xl border border-white/10 text-foreground font-semibold hover:bg-white/5 transition-colors inline-flex items-center gap-2">
                Giriş Yap
              </Link>
            </div>
            <div className="flex items-center gap-6 mt-10 text-sm text-muted-foreground">
              <span className="flex items-center gap-1.5"><Check size={14} className="text-green-400" /> Ücretsiz başla</span>
              <span className="flex items-center gap-1.5"><Check size={14} className="text-green-400" /> Kredi kartı gerekmez</span>
              <span className="flex items-center gap-1.5"><Check size={14} className="text-green-400" /> Anında erişim</span>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8, delay: 0.3 }} className="hidden lg:block">
            <div className="relative">
              <div className="absolute -inset-4 rounded-3xl bg-gradient-to-r from-neon-blue/20 to-neon-purple/20 blur-2xl" />
              <img src={CHAT_IMG} alt="CortxGPT AI" className="relative rounded-2xl border border-white/10 shadow-2xl w-full" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* ===== FEATURES ===== */}
      <section id="features" className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <img src={FEATURES_IMG} alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-background/90" />
        </div>
        <div className="container relative z-10">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} transition={{ duration: 0.6 }} className="text-center mb-16">
            <span className="inline-block px-4 py-1.5 rounded-full glass-card text-xs text-neon-blue mb-4">Özellikler</span>
            <h2 className="text-3xl sm:text-4xl font-bold font-[var(--font-heading)] mb-4">
              Güçlü <span className="gradient-text">AI Araçları</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              CortxGPT, yapay zeka teknolojisinin tüm gücünü parmaklarınızın ucuna getiriyor.
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUp}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className="glass-card glass-card-hover rounded-xl p-6 transition-all duration-300 group"
              >
                <div className="w-11 h-11 rounded-lg bg-neon-blue/10 flex items-center justify-center mb-4 group-hover:neon-glow transition-shadow">
                  <f.icon size={20} className="text-neon-blue" />
                </div>
                <h3 className="text-base font-semibold mb-2 font-[var(--font-heading)]">{f.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== PRICING ===== */}
      <section id="pricing" className="py-24 relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full bg-neon-purple/5 blur-[150px]" />
        <div className="container relative z-10">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} transition={{ duration: 0.6 }} className="text-center mb-16">
            <span className="inline-block px-4 py-1.5 rounded-full glass-card text-xs text-neon-purple mb-4">Fiyatlandırma</span>
            <h2 className="text-3xl sm:text-4xl font-bold font-[var(--font-heading)] mb-4">
              Size Uygun <span className="gradient-text">Planı Seçin</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Her ihtiyaca uygun esnek planlar. VIP ile en üst düzey deneyimi yaşayın.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {plans.map((plan, i) => (
              <motion.div
                key={plan.name}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUp}
                transition={{ duration: 0.5, delay: i * 0.15 }}
                className={`relative glass-card rounded-2xl p-7 transition-all duration-300 hover:-translate-y-2 ${
                  plan.popular ? "border-neon-blue/40 neon-glow" : plan.vip ? "border-neon-purple/40 neon-glow-purple" : "border-white/5"
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full gradient-btn text-xs font-semibold text-white">
                    En Popüler
                  </div>
                )}
                {plan.vip && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-xs font-semibold text-white flex items-center gap-1">
                    <Crown size={12} /> VIP
                  </div>
                )}

                <div className="flex items-center gap-3 mb-4 mt-2">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    plan.vip ? "bg-amber-500/10" : "bg-neon-blue/10"
                  }`}>
                    <plan.icon size={20} className={plan.vip ? "text-amber-400" : "text-neon-blue"} />
                  </div>
                  <div>
                    <h3 className="font-semibold font-[var(--font-heading)]">{plan.name}</h3>
                    <p className="text-xs text-muted-foreground">{plan.desc}</p>
                  </div>
                </div>

                <div className="mb-5">
                  <span className="text-4xl font-bold font-[var(--font-heading)]">{plan.price}</span>
                  <span className="text-muted-foreground text-sm">{plan.period}</span>
                </div>

                <div className="text-xs font-medium text-neon-blue bg-neon-blue/10 rounded-lg px-3 py-2 mb-5">
                  {plan.credits}
                </div>

                <ul className="space-y-2.5 mb-6">
                  {plan.features.map((feat) => (
                    <li key={feat} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <Check size={15} className={`shrink-0 mt-0.5 ${plan.vip ? "text-amber-400" : "text-neon-blue"}`} />
                      {feat}
                    </li>
                  ))}
                </ul>

                <button className={`w-full py-3 rounded-xl font-semibold text-sm transition-all ${
                  plan.popular
                    ? "gradient-btn text-white"
                    : plan.vip
                    ? "bg-gradient-to-r from-amber-500 to-orange-500 text-white hover:shadow-lg hover:shadow-amber-500/20"
                    : "border border-white/10 text-foreground hover:bg-white/5"
                }`}>
                  {plan.cta}
                </button>
              </motion.div>
            ))}
          </div>

          {/* VIP Info */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-12 max-w-3xl mx-auto glass-card rounded-2xl p-6 border-amber-500/20">
            <div className="flex items-center gap-3 mb-3">
              <Crown size={20} className="text-amber-400" />
              <h3 className="font-semibold font-[var(--font-heading)]">VIP Kredi Sistemi</h3>
            </div>
            <div className="grid sm:grid-cols-3 gap-4 text-sm text-muted-foreground">
              <div className="bg-white/5 rounded-lg p-3 text-center">
                <p className="text-2xl font-bold text-amber-400 font-[var(--font-heading)]">3000</p>
                <p>Başlangıç Kredisi</p>
              </div>
              <div className="bg-white/5 rounded-lg p-3 text-center">
                <p className="text-2xl font-bold text-amber-400 font-[var(--font-heading)]">500</p>
                <p>Günlük Kredi</p>
              </div>
              <div className="bg-white/5 rounded-lg p-3 text-center">
                <p className="text-2xl font-bold text-amber-400 font-[var(--font-heading)]">7</p>
                <p>İşlem Başı Kredi</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ===== ABOUT ===== */}
      <section id="about" className="py-24 relative overflow-hidden">
        <div className="container relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.7 }}>
              <div className="relative">
                <div className="absolute -inset-4 rounded-3xl bg-gradient-to-r from-neon-blue/10 to-neon-purple/10 blur-2xl" />
                <img src={ABOUT_IMG} alt="CortxGPT Hakkında" className="relative rounded-2xl border border-white/10 w-full" />
              </div>
            </motion.div>

            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} transition={{ duration: 0.7 }}>
              <span className="inline-block px-4 py-1.5 rounded-full glass-card text-xs text-neon-blue mb-4">Hakkımızda</span>
              <h2 className="text-3xl sm:text-4xl font-bold font-[var(--font-heading)] mb-6">
                Yapay Zekanın <span className="gradient-text">Geleceğini</span> Şekillendiriyoruz
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-6">
                CortxGPT, en son yapay zeka teknolojilerini kullanarak bireylere ve işletmelere güçlü, güvenilir ve kullanımı kolay AI çözümleri sunan yenilikçi bir platformdur. Misyonumuz, yapay zekayı herkes için erişilebilir kılmaktır.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-8">
                Gelişmiş dil modelleri, görsel üretim, kod yazma desteği ve canlı destek sistemimiz ile kullanıcılarımıza kapsamlı bir AI deneyimi sunuyoruz. Güvenlik ve gizlilik bizim için en önemli önceliktir.
              </p>
              <div className="grid grid-cols-3 gap-4">
                {[
                  { val: "100K+", label: "Kullanıcı" },
                  { val: "50+", label: "Dil Desteği" },
                  { val: "99.9%", label: "Uptime" },
                ].map((s) => (
                  <div key={s.label} className="glass-card rounded-xl p-4 text-center">
                    <p className="text-2xl font-bold gradient-text font-[var(--font-heading)]">{s.val}</p>
                    <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
