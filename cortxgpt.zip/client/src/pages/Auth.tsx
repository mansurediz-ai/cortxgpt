import { useState } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Eye, EyeOff, Mail, Lock, User, ArrowRight, AlertCircle, X } from "lucide-react";
import { toast } from "sonner";
import { registerUser } from "@/lib/store";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663469047697/7PMHtqMX2cLBqPHn4Fvif7/ai-brain-logo-UPKum59kVPznZdwMyoKdyZ.webp";

interface StoredUser {
  name: string;
  email: string;
  password: string;
  createdAt: string;
  provider?: "email" | "google";
  avatar?: string;
}

function getUsers(): StoredUser[] {
  try {
    return JSON.parse(localStorage.getItem("cortxgpt_users") || "[]");
  } catch {
    return [];
  }
}

function saveUsers(users: StoredUser[]) {
  localStorage.setItem("cortxgpt_users", JSON.stringify(users));
}

// Google Sign-In Modal
function GoogleSignInModal({ isOpen, onClose, onSuccess, mode }: {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: StoredUser) => void;
  mode: "login" | "register";
}) {
  const [step, setStep] = useState<"email" | "password" | "loading">("email");
  const [gEmail, setGEmail] = useState("");
  const [gPassword, setGPassword] = useState("");
  const [gError, setGError] = useState("");
  const [showGPass, setShowGPass] = useState(false);

  const handleEmailNext = () => {
    if (!gEmail.trim() || !gEmail.includes("@")) {
      setGError("Geçerli bir e-posta adresi girin.");
      return;
    }
    setGError("");
    setStep("password");
  };

  const handlePasswordSubmit = () => {
    if (!gPassword.trim()) {
      setGError("Şifre gereklidir.");
      return;
    }
    if (gPassword.length < 6) {
      setGError("Şifre en az 6 karakter olmalıdır.");
      return;
    }
    setGError("");
    setStep("loading");

    setTimeout(() => {
      const users = getUsers();

      if (mode === "login") {
        const found = users.find((u) => u.email.toLowerCase() === gEmail.toLowerCase());
        if (!found) {
          setStep("password");
          setGError("Bu Google hesabına ait bir kayıt bulunamadı.");
          return;
        }
        if (found.password !== gPassword) {
          setStep("password");
          setGError("Şifre yanlış. Lütfen tekrar deneyin.");
          return;
        }
        onSuccess(found);
      } else {
        const exists = users.find((u) => u.email.toLowerCase() === gEmail.toLowerCase());
        if (exists) {
          setStep("password");
          setGError("Bu e-posta adresi zaten kayıtlı.");
          return;
        }
        const googleName = gEmail.split("@")[0].replace(/[._]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
        const newUser: StoredUser = {
          name: googleName,
          email: gEmail,
          password: gPassword,
          createdAt: new Date().toISOString(),
          provider: "google",
          avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(googleName)}&background=4285F4&color=fff`,
        };
        saveUsers([...users, newUser]);
        registerUser({ name: googleName, email: gEmail, password: gPassword, provider: "google" });
        onSuccess(newUser);
      }
    }, 1200);
  };

  const resetAndClose = () => {
    setStep("email");
    setGEmail("");
    setGPassword("");
    setGError("");
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex items-center justify-center p-4"
      >
        {/* Backdrop */}
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={resetAndClose} />

        {/* Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-sm bg-[#202124] rounded-2xl shadow-2xl overflow-hidden border border-white/10"
        >
          {/* Google Header */}
          <div className="p-6 pb-4">
            <div className="flex items-center justify-between mb-6">
              <svg width="24" height="24" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
              <button onClick={resetAndClose} className="p-1 rounded-full hover:bg-white/10 text-gray-400">
                <X size={18} />
              </button>
            </div>

            <h3 className="text-xl font-normal text-white mb-1">
              {step === "email" ? "Oturum açın" : step === "password" ? "Hoş geldiniz" : "Doğrulanıyor..."}
            </h3>
            <p className="text-sm text-gray-400 mb-1">
              {step === "email"
                ? "Google Hesabınızı kullanın"
                : step === "password"
                ? gEmail
                : "Google ile bağlanılıyor..."}
            </p>
          </div>

          {/* Content */}
          <div className="px-6 pb-6">
            {/* Error */}
            {gError && (
              <motion.div
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20 mb-4"
              >
                <AlertCircle size={14} className="text-red-400 shrink-0 mt-0.5" />
                <p className="text-xs text-red-400">{gError}</p>
              </motion.div>
            )}

            {step === "email" && (
              <div className="space-y-4">
                <div>
                  <input
                    type="email"
                    value={gEmail}
                    onChange={(e) => { setGEmail(e.target.value); setGError(""); }}
                    placeholder="E-posta veya telefon"
                    autoFocus
                    className="w-full px-4 py-3 rounded-lg bg-transparent border border-gray-600 text-sm text-white placeholder:text-gray-500 outline-none focus:border-[#4285F4] transition-colors"
                    onKeyDown={(e) => e.key === "Enter" && handleEmailNext()}
                  />
                </div>
                <p className="text-xs text-gray-500">
                  Bu sizin bilgisayarınız değil mi?{" "}
                  <span className="text-[#8AB4F8] cursor-pointer hover:underline">Gizli modu kullanın</span>
                </p>
                <div className="flex items-center justify-between pt-2">
                  <button onClick={resetAndClose} className="text-sm text-[#8AB4F8] hover:underline">
                    Hesap oluştur
                  </button>
                  <button
                    onClick={handleEmailNext}
                    className="px-6 py-2 rounded-full bg-[#4285F4] text-white text-sm font-medium hover:bg-[#3B78E7] transition-colors"
                  >
                    İleri
                  </button>
                </div>
              </div>
            )}

            {step === "password" && (
              <div className="space-y-4">
                <button
                  onClick={() => { setStep("email"); setGError(""); }}
                  className="flex items-center gap-2 text-sm text-[#8AB4F8] hover:underline mb-2"
                >
                  <div className="w-6 h-6 rounded-full bg-[#4285F4]/20 flex items-center justify-center text-xs text-[#8AB4F8]">
                    {gEmail[0]?.toUpperCase()}
                  </div>
                  {gEmail}
                </button>
                <div className="relative">
                  <input
                    type={showGPass ? "text" : "password"}
                    value={gPassword}
                    onChange={(e) => { setGPassword(e.target.value); setGError(""); }}
                    placeholder="Şifrenizi girin"
                    autoFocus
                    className="w-full px-4 py-3 rounded-lg bg-transparent border border-gray-600 text-sm text-white placeholder:text-gray-500 outline-none focus:border-[#4285F4] transition-colors pr-12"
                    onKeyDown={(e) => e.key === "Enter" && handlePasswordSubmit()}
                  />
                  <button
                    type="button"
                    onClick={() => setShowGPass(!showGPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                  >
                    {showGPass ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                <label className="flex items-center gap-2 text-sm text-gray-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showGPass}
                    onChange={() => setShowGPass(!showGPass)}
                    className="w-4 h-4 rounded border-gray-600 bg-transparent accent-[#4285F4]"
                  />
                  Şifreyi göster
                </label>
                <div className="flex items-center justify-between pt-2">
                  <button className="text-sm text-[#8AB4F8] hover:underline">
                    Şifrenizi mi unuttunuz?
                  </button>
                  <button
                    onClick={handlePasswordSubmit}
                    className="px-6 py-2 rounded-full bg-[#4285F4] text-white text-sm font-medium hover:bg-[#3B78E7] transition-colors"
                  >
                    İleri
                  </button>
                </div>
              </div>
            )}

            {step === "loading" && (
              <div className="flex flex-col items-center justify-center py-8 gap-4">
                <div className="relative w-10 h-10">
                  <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-[#4285F4] border-r-[#EA4335] border-b-[#FBBC05] border-l-[#34A853] animate-spin" />
                </div>
                <p className="text-sm text-gray-400">Lütfen bekleyin...</p>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-6 py-4 border-t border-white/5 flex items-center justify-between">
            <span className="text-xs text-gray-500">Türkçe</span>
            <div className="flex gap-4 text-xs text-gray-500">
              <span className="hover:text-gray-300 cursor-pointer">Yardım</span>
              <span className="hover:text-gray-300 cursor-pointer">Gizlilik</span>
              <span className="hover:text-gray-300 cursor-pointer">Şartlar</span>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// ===== MAIN AUTH PAGE =====
export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [googleModalOpen, setGoogleModalOpen] = useState(false);
  const [, navigate] = useLocation();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!email.trim()) { setError("E-posta adresi gereklidir."); return; }
    if (!password.trim()) { setError("Şifre gereklidir."); return; }
    if (!isLogin && !name.trim()) { setError("Ad Soyad gereklidir."); return; }
    if (password.length < 6) { setError("Şifre en az 6 karakter olmalıdır."); return; }

    setLoading(true);

    setTimeout(() => {
      const users = getUsers();

      if (isLogin) {
        const found = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
        if (!found) {
          setError("Bu e-posta adresine ait bir hesap bulunamadı.");
          setLoading(false);
          return;
        }
        if (found.password !== password) {
          setError("Şifre yanlış. Lütfen tekrar deneyin.");
          setLoading(false);
          return;
        }
        localStorage.setItem("cortxgpt_current_user", JSON.stringify(found));
        toast.success("Giriş başarılı! Yönlendiriliyorsunuz...");
        setTimeout(() => navigate("/chat"), 800);
      } else {
        const exists = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
        if (exists) {
          setError("Bu e-posta adresi zaten kayıtlı. Giriş yapmayı deneyin.");
          setLoading(false);
          return;
        }
        const newUser: StoredUser = { name, email, password, createdAt: new Date().toISOString(), provider: "email" };
        saveUsers([...users, newUser]);
        registerUser({ name, email, password, provider: "email" });
        toast.success("Kayıt başarılı! Şimdi giriş yapabilirsiniz.");
        setIsLogin(true);
        setName("");
        setPassword("");
      }
      setLoading(false);
    }, 600);
  };

  const handleGoogleSuccess = (user: StoredUser) => {
    setGoogleModalOpen(false);
    localStorage.setItem("cortxgpt_current_user", JSON.stringify(user));
    toast.success("Google ile giriş başarılı! Yönlendiriliyorsunuz...");
    setTimeout(() => navigate("/chat"), 800);
  };

  return (
    <div className="min-h-screen flex relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-neon-blue/8 blur-[150px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-neon-purple/8 blur-[150px]" />
      </div>

      {/* Google Sign-In Modal */}
      <GoogleSignInModal
        isOpen={googleModalOpen}
        onClose={() => setGoogleModalOpen(false)}
        onSuccess={handleGoogleSuccess}
        mode={isLogin ? "login" : "register"}
      />

      {/* Left - Brand */}
      <div className="hidden lg:flex flex-1 items-center justify-center relative">
        <div className="max-w-md text-center px-8">
          <Link href="/" className="inline-flex items-center gap-3 mb-8">
            <img src={LOGO_URL} alt="CortxGPT" className="w-12 h-12" />
            <span className="text-3xl font-bold gradient-text font-[var(--font-heading)]">CortxGPT</span>
          </Link>
          <h2 className="text-2xl font-bold font-[var(--font-heading)] mb-4">Yapay Zeka ile Tanışın</h2>
          <p className="text-muted-foreground leading-relaxed">
            Akıllı sohbet, hızlı cevaplar ve gelişmiş AI araçları ile geleceğin teknolojisini bugün deneyimleyin.
          </p>
          <div className="mt-10 grid grid-cols-3 gap-4">
            {[{ v: "100K+", l: "Kullanıcı" }, { v: "7/24", l: "Destek" }, { v: "50+", l: "Dil" }].map((s) => (
              <div key={s.l} className="glass-card rounded-xl p-4">
                <p className="text-lg font-bold gradient-text font-[var(--font-heading)]">{s.v}</p>
                <p className="text-xs text-muted-foreground">{s.l}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right - Form */}
      <div className="flex-1 flex items-center justify-center p-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          {/* Mobile logo */}
          <div className="lg:hidden flex items-center justify-center gap-2 mb-8">
            <Link href="/">
              <img src={LOGO_URL} alt="CortxGPT" className="w-10 h-10" />
            </Link>
            <span className="text-2xl font-bold gradient-text font-[var(--font-heading)]">CortxGPT</span>
          </div>

          <div className="glass-card rounded-2xl p-8 border border-white/5">
            <h2 className="text-2xl font-bold font-[var(--font-heading)] mb-2">
              {isLogin ? "Giriş Yap" : "Hesap Oluştur"}
            </h2>
            <p className="text-sm text-muted-foreground mb-6">
              {isLogin ? "Hesabınıza giriş yaparak devam edin." : "Ücretsiz hesap oluşturun ve hemen başlayın."}
            </p>

            {/* Google Button */}
            <button
              onClick={() => setGoogleModalOpen(true)}
              className="w-full flex items-center justify-center gap-3 py-3 rounded-xl border border-white/10 text-sm text-foreground hover:bg-white/5 transition-colors mb-6"
            >
              <svg width="18" height="18" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
              Google ile {isLogin ? "Giriş Yap" : "Kayıt Ol"}
            </button>

            <div className="flex items-center gap-3 mb-6">
              <div className="flex-1 h-px bg-white/10" />
              <span className="text-xs text-muted-foreground">veya</span>
              <div className="flex-1 h-px bg-white/10" />
            </div>

            {/* Error Message */}
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-start gap-2.5 p-3 rounded-xl bg-red-500/10 border border-red-500/20 mb-4"
              >
                <AlertCircle size={16} className="text-red-400 shrink-0 mt-0.5" />
                <p className="text-sm text-red-400">{error}</p>
              </motion.div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <div className="relative">
                  <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => { setName(e.target.value); setError(""); }}
                    placeholder="Ad Soyad"
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-neon-blue/50 transition-colors"
                  />
                </div>
              )}
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); setError(""); }}
                  placeholder="E-posta adresi"
                  className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-neon-blue/50 transition-colors"
                />
              </div>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); setError(""); }}
                  placeholder="Şifre"
                  className="w-full pl-10 pr-12 py-3 rounded-xl bg-white/5 border border-white/10 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-neon-blue/50 transition-colors"
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>

              {isLogin && (
                <div className="flex justify-end">
                  <a href="#" className="text-xs text-neon-blue hover:underline">Şifremi Unuttum</a>
                </div>
              )}

              <button type="submit" disabled={loading} className="w-full gradient-btn py-3 rounded-xl text-white font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-60">
                {loading ? (
                  <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Doğrulanıyor...</>
                ) : (
                  <>{isLogin ? "Giriş Yap" : "Kayıt Ol"} <ArrowRight size={16} /></>
                )}
              </button>
            </form>

            <p className="text-sm text-muted-foreground text-center mt-6">
              {isLogin ? "Hesabınız yok mu?" : "Zaten hesabınız var mı?"}{" "}
              <button onClick={() => { setIsLogin(!isLogin); setError(""); }} className="text-neon-blue hover:underline font-medium">
                {isLogin ? "Kayıt Ol" : "Giriş Yap"}
              </button>
            </p>
          </div>

          <p className="text-[11px] text-muted-foreground text-center mt-4">
            Devam ederek <a href="#" className="text-neon-blue hover:underline">Kullanım Koşulları</a> ve{" "}
            <a href="#" className="text-neon-blue hover:underline">Gizlilik Politikası</a>'nı kabul etmiş olursunuz.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
