import { useState, useEffect, useCallback } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  LayoutDashboard, Users, Shield, CreditCard, Coins, Key, Settings,
  Receipt, UserCog, FileText, Bell, Wrench, LogOut, Menu, X, Crown,
  TrendingUp, UserPlus, DollarSign, Activity, ChevronDown, ChevronRight,
  Search, MoreVertical, Edit, Trash2, Ban, Check, Plus, Eye, EyeOff,
  ToggleLeft, ToggleRight, Save, AlertTriangle, Megaphone, Gift,
  ArrowLeft, Bot, Zap, Globe, MessageSquare, Image, Code, Headphones,
  Lock, Unlock, RefreshCw, Download, Filter, Calendar, Wifi, WifiOff,
  Phone, Clock, Send, Volume2, VolumeX, BarChart3, PieChart
} from "lucide-react";
import {
  getStats, startLiveStatSimulation, getRegisteredUsers, getNotifications,
  getUnreadCount, markAllRead, getWaitingTickets, getActiveTickets,
  getClosedTickets, connectToTicket, closeTicket, addMessageToTicket,
  addCredits, giveVip, banUser, updateUser, addNotification,
  type SupportTicket, type RegisteredUser, type AdminNotification, type LiveStats
} from "@/lib/store";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663469047697/7PMHtqMX2cLBqPHn4Fvif7/ai-brain-logo-UPKum59kVPznZdwMyoKdyZ.webp";

const menuItems = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "live-support", label: "Canlı Destek", icon: Headphones },
  { id: "registrations", label: "Kayıt Bildirimleri", icon: UserPlus },
  { id: "admins", label: "Admin Yönetimi", icon: Shield },
  { id: "packages", label: "Paket & Fiyat", icon: CreditCard },
  { id: "credits", label: "Kredi Sistemi", icon: Coins },
  { id: "permissions", label: "Yetki & Erişim", icon: Key },
  { id: "settings", label: "Sistem Ayarları", icon: Settings },
  { id: "payments", label: "Ödeme & Satış", icon: Receipt },
  { id: "users", label: "Kullanıcılar", icon: UserCog },
  { id: "logs", label: "Log & Güvenlik", icon: FileText },
  { id: "notifications", label: "Bildirimler", icon: Bell },
  { id: "extras", label: "Ekstra Araçlar", icon: Wrench },
];

// ===== STAT CARD =====
function StatCard({ icon: Icon, label, value, change, color, pulse }: { icon: any; label: string; value: string; change?: string; color: string; pulse?: boolean }) {
  return (
    <div className="glass-card glass-card-hover rounded-xl p-4 transition-all duration-300">
      <div className="flex items-start justify-between mb-2">
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${color}`}>
          <Icon size={16} />
        </div>
        {pulse && <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />}
        {change && <span className="text-[10px] text-green-400 bg-green-400/10 px-1.5 py-0.5 rounded-full">{change}</span>}
      </div>
      <p className="text-xl font-bold font-[var(--font-heading)]">{value}</p>
      <p className="text-[11px] text-muted-foreground mt-0.5">{label}</p>
    </div>
  );
}

// ===== LIVE DASHBOARD =====
function DashboardSection() {
  const [stats, setStats] = useState<LiveStats>(getStats());
  const [users, setUsers] = useState<RegisteredUser[]>(getRegisteredUsers());

  useEffect(() => {
    const stop = startLiveStatSimulation();
    const iv = setInterval(() => {
      setStats(getStats());
      setUsers(getRegisteredUsers());
    }, 2000);
    return () => { stop(); clearInterval(iv); };
  }, []);

  const fmt = (n: number) => n.toLocaleString("tr-TR");

  return (
    <div className="space-y-5">
      {/* Live Indicator */}
      <div className="flex items-center gap-2 text-xs text-green-400">
        <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
        Canlı Güncelleme Aktif
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3">
        <StatCard icon={Wifi} label="Aktif Kullanıcı" value={fmt(stats.activeUsers)} color="bg-green-500/10 text-green-400" pulse />
        <StatCard icon={Users} label="Toplam Kullanıcı" value={fmt(stats.totalUsers)} change="+12%" color="bg-neon-blue/10 text-neon-blue" />
        <StatCard icon={UserPlus} label="Bugün Kayıt" value={fmt(stats.todayRegistrations)} change="+18%" color="bg-cyan-500/10 text-cyan-400" />
        <StatCard icon={Crown} label="VIP Kullanıcı" value={fmt(stats.vipUsers)} change="+23%" color="bg-amber-500/10 text-amber-400" />
        <StatCard icon={MessageSquare} label="Aktif Sohbet" value={fmt(stats.chattingUsers)} color="bg-neon-purple/10 text-neon-purple" pulse />
        <StatCard icon={Headphones} label="Destek Bekleyen" value={fmt(stats.pendingSupport)} color="bg-red-500/10 text-red-400" pulse />
        <StatCard icon={Coins} label="Bugün Kredi" value={fmt(stats.todayCreditsUsed)} change="+5%" color="bg-orange-500/10 text-orange-400" />
        <StatCard icon={Zap} label="AI İstek" value={fmt(stats.activeAiRequests)} color="bg-pink-500/10 text-pink-400" pulse />
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-2 gap-4">
        {/* User Chart */}
        <div className="glass-card rounded-xl p-4">
          <h3 className="text-sm font-semibold font-[var(--font-heading)] mb-3 flex items-center gap-2"><BarChart3 size={14} className="text-neon-blue" /> Günlük Kullanıcı</h3>
          <div className="flex items-end gap-2 h-32">
            {stats.dailyUserStats.map((v, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full rounded-t bg-gradient-to-t from-neon-blue to-neon-purple transition-all duration-500" style={{ height: `${(v / Math.max(...stats.dailyUserStats)) * 100}%` }} />
                <span className="text-[9px] text-muted-foreground">{["Pzt","Sal","Çar","Per","Cum","Cmt","Paz"][i]}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Credit Chart */}
        <div className="glass-card rounded-xl p-4">
          <h3 className="text-sm font-semibold font-[var(--font-heading)] mb-3 flex items-center gap-2"><PieChart size={14} className="text-neon-purple" /> Günlük Kredi Kullanımı</h3>
          <div className="flex items-end gap-2 h-32">
            {stats.dailyCreditStats.map((v, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full rounded-t bg-gradient-to-t from-neon-purple to-pink-500 transition-all duration-500" style={{ height: `${(v / Math.max(...stats.dailyCreditStats)) * 100}%` }} />
                <span className="text-[9px] text-muted-foreground">{["Pzt","Sal","Çar","Per","Cum","Cmt","Paz"][i]}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Registrations */}
      <div className="glass-card rounded-xl p-4">
        <h3 className="text-sm font-semibold font-[var(--font-heading)] mb-3">Son Kayıt Olanlar</h3>
        <div className="space-y-2">
          {users.slice(0, 5).map((u) => (
            <div key={u.id} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-neon-blue/10 flex items-center justify-center text-neon-blue text-xs font-bold">{u.name[0]}</div>
                <div>
                  <p className="text-sm font-medium">{u.name}</p>
                  <p className="text-[10px] text-muted-foreground">{u.email}</p>
                </div>
              </div>
              <div className="text-right">
                <span className={`text-[10px] px-2 py-0.5 rounded-full ${u.role === "VIP Premium" ? "bg-amber-500/10 text-amber-400" : u.role === "Pro" ? "bg-neon-purple/10 text-neon-purple" : "bg-white/10 text-muted-foreground"}`}>{u.role}</span>
                <p className="text-[9px] text-muted-foreground mt-0.5">{new Date(u.createdAt).toLocaleString("tr-TR")}</p>
              </div>
            </div>
          ))}
          {users.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">Henüz kayıtlı kullanıcı yok</p>}
        </div>
      </div>
    </div>
  );
}

// ===== LIVE SUPPORT SECTION =====
function LiveSupportSection() {
  const [waiting, setWaiting] = useState<SupportTicket[]>(getWaitingTickets());
  const [active, setActive] = useState<SupportTicket[]>(getActiveTickets());
  const [closed, setClosed] = useState<SupportTicket[]>(getClosedTickets());
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [adminMsg, setAdminMsg] = useState("");
  const [soundOn, setSoundOn] = useState(true);
  const [tab, setTab] = useState<"waiting" | "active" | "closed">("waiting");

  useEffect(() => {
    const iv = setInterval(() => {
      const w = getWaitingTickets();
      const a = getActiveTickets();
      const c = getClosedTickets();
      if (soundOn && w.length > waiting.length) {
        try { new Audio("data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQ==").play().catch(() => {}); } catch {}
        toast.info("Yeni destek talebi geldi!");
      }
      setWaiting(w);
      setActive(a);
      setClosed(c);
      if (selectedTicket) {
        const updated = [...w, ...a, ...c].find((t) => t.id === selectedTicket.id);
        if (updated) setSelectedTicket(updated);
      }
    }, 1500);
    return () => clearInterval(iv);
  }, [waiting.length, soundOn, selectedTicket]);

  const handleConnect = (ticketId: string) => {
    connectToTicket(ticketId, "Admin");
    toast.success("Kullanıcıya bağlandınız!");
  };

  const handleClose = (ticketId: string) => {
    closeTicket(ticketId);
    setSelectedTicket(null);
    toast.info("Destek görüşmesi kapatıldı");
  };

  const sendAdminMsg = () => {
    if (!adminMsg.trim() || !selectedTicket) return;
    addMessageToTicket(selectedTicket.id, adminMsg, "admin");
    setAdminMsg("");
  };

  const timeSince = (date: string) => {
    const s = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
    if (s < 60) return `${s}sn`;
    if (s < 3600) return `${Math.floor(s / 60)}dk`;
    return `${Math.floor(s / 3600)}sa`;
  };

  const tickets = tab === "waiting" ? waiting : tab === "active" ? active : closed;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h3 className="font-semibold font-[var(--font-heading)]">Canlı Destek Talepleri</h3>
          {waiting.length > 0 && <span className="w-5 h-5 rounded-full bg-red-500 text-white text-[10px] flex items-center justify-center font-bold animate-pulse">{waiting.length}</span>}
        </div>
        <button onClick={() => setSoundOn(!soundOn)} className="p-2 rounded-lg hover:bg-white/5 text-muted-foreground">
          {soundOn ? <Volume2 size={16} /> : <VolumeX size={16} />}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        {([["waiting", "Bekleyen", waiting.length], ["active", "Aktif", active.length], ["closed", "Kapalı", closed.length]] as const).map(([key, label, count]) => (
          <button key={key} onClick={() => setTab(key)} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${tab === key ? "bg-neon-blue/10 text-neon-blue" : "text-muted-foreground hover:bg-white/5"}`}>
            {label} ({count})
          </button>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        {/* Ticket List */}
        <div className="space-y-2">
          {tickets.length === 0 && <div className="glass-card rounded-xl p-8 text-center text-muted-foreground text-sm">{tab === "waiting" ? "Bekleyen destek talebi yok" : tab === "active" ? "Aktif görüşme yok" : "Kapalı kayıt yok"}</div>}
          {tickets.map((t) => (
            <div key={t.id} onClick={() => setSelectedTicket(t)} className={`glass-card rounded-xl p-4 cursor-pointer transition-all hover:border-neon-blue/30 ${selectedTicket?.id === t.id ? "border-neon-blue/50 bg-neon-blue/5" : ""}`}>
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${t.priority === "vip" ? "bg-amber-500/10 text-amber-400" : "bg-neon-blue/10 text-neon-blue"}`}>{t.userName[0]}</div>
                  <div>
                    <p className="text-sm font-medium flex items-center gap-1">{t.userName} {t.priority === "vip" && <Crown size={10} className="text-amber-400" />}</p>
                    <p className="text-[10px] text-muted-foreground">{t.userEmail}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${t.status === "waiting" ? "bg-amber-500/10 text-amber-400" : t.status === "connected" ? "bg-green-500/10 text-green-400" : "bg-white/10 text-muted-foreground"}`}>
                    {t.status === "waiting" ? "Bekliyor" : t.status === "connected" ? "Bağlı" : "Kapalı"}
                  </span>
                  <p className="text-[9px] text-muted-foreground mt-0.5">{t.ticketNo}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                <span className="flex items-center gap-1"><Clock size={10} /> {timeSince(t.createdAt)}</span>
                <span className="flex items-center gap-1"><Users size={10} /> Sıra: #{t.queuePosition}</span>
                <span className={`flex items-center gap-1 ${t.isOnline ? "text-green-400" : "text-red-400"}`}><Wifi size={10} /> {t.isOnline ? "Online" : "Offline"}</span>
              </div>
              {t.status === "waiting" && (
                <button onClick={(e) => { e.stopPropagation(); handleConnect(t.id); }} className="mt-2 w-full gradient-btn py-1.5 rounded-lg text-white text-xs font-medium">Bağlan</button>
              )}
            </div>
          ))}
        </div>

        {/* Chat Panel */}
        <div className="glass-card rounded-xl overflow-hidden flex flex-col" style={{ minHeight: 400 }}>
          {selectedTicket ? (
            <>
              <div className="p-3 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-neon-blue/10 flex items-center justify-center text-neon-blue text-xs font-bold">{selectedTicket.userName[0]}</div>
                  <div>
                    <p className="text-xs font-medium">{selectedTicket.userName}</p>
                    <p className="text-[9px] text-muted-foreground">{selectedTicket.ticketNo}</p>
                  </div>
                </div>
                {selectedTicket.status === "connected" && (
                  <button onClick={() => handleClose(selectedTicket.id)} className="px-3 py-1 rounded-lg bg-red-500/10 text-red-400 text-xs hover:bg-red-500/20">Kapat</button>
                )}
              </div>
              <div className="flex-1 overflow-y-auto p-3 space-y-2 scrollbar-thin">
                {selectedTicket.messages.map((msg) => (
                  <div key={msg.id} className={`flex ${msg.sender === "admin" ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[80%] px-3 py-2 rounded-xl text-xs ${msg.sender === "admin" ? "gradient-btn text-white rounded-br-sm" : msg.sender === "user" ? "bg-white/5 text-foreground rounded-bl-sm" : "bg-neon-blue/5 text-muted-foreground italic"}`}>
                      <p>{msg.text}</p>
                      <p className="text-[9px] mt-0.5 opacity-60">{msg.time}</p>
                    </div>
                  </div>
                ))}
              </div>
              {selectedTicket.status === "connected" && (
                <div className="p-3 border-t border-white/5">
                  <div className="flex gap-2">
                    <input value={adminMsg} onChange={(e) => setAdminMsg(e.target.value)} onKeyDown={(e) => e.key === "Enter" && sendAdminMsg()} placeholder="Mesaj yazın..." className="flex-1 px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-xs outline-none focus:border-neon-blue/50" />
                    <button onClick={sendAdminMsg} disabled={!adminMsg.trim()} className="p-2 rounded-lg gradient-btn text-white disabled:opacity-30"><Send size={14} /></button>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground text-sm">Bir destek talebi seçin</div>
          )}
        </div>
      </div>
    </div>
  );
}

// ===== REGISTRATION NOTIFICATIONS =====
function RegistrationsSection() {
  const [users, setUsers] = useState<RegisteredUser[]>(getRegisteredUsers());
  const [selectedUser, setSelectedUser] = useState<RegisteredUser | null>(null);
  const [creditAmount, setCreditAmount] = useState(100);

  useEffect(() => {
    const iv = setInterval(() => setUsers(getRegisteredUsers()), 2000);
    return () => clearInterval(iv);
  }, []);

  const handleAddCredits = (userId: string) => {
    addCredits(userId, creditAmount);
    toast.success(`${creditAmount} kredi yüklendi!`);
    setUsers(getRegisteredUsers());
  };

  const handleGiveVip = (userId: string) => {
    giveVip(userId);
    toast.success("VIP üyelik verildi!");
    setUsers(getRegisteredUsers());
  };

  const handleBan = (userId: string) => {
    banUser(userId);
    toast.error("Kullanıcı banlandı!");
    setUsers(getRegisteredUsers());
  };

  const today = users.filter((u) => new Date(u.createdAt).toDateString() === new Date().toDateString());
  const thisWeek = users.filter((u) => Date.now() - new Date(u.createdAt).getTime() < 7 * 86400000);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <h3 className="font-semibold font-[var(--font-heading)]">Kayıt Bildirimleri</h3>
        <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
        <span className="text-xs text-green-400">Canlı</span>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="glass-card rounded-xl p-3 text-center">
          <p className="text-lg font-bold text-neon-blue">{today.length}</p>
          <p className="text-[10px] text-muted-foreground">Bugün</p>
        </div>
        <div className="glass-card rounded-xl p-3 text-center">
          <p className="text-lg font-bold text-neon-purple">{thisWeek.length}</p>
          <p className="text-[10px] text-muted-foreground">Bu Hafta</p>
        </div>
        <div className="glass-card rounded-xl p-3 text-center">
          <p className="text-lg font-bold text-amber-400">{users.length}</p>
          <p className="text-[10px] text-muted-foreground">Toplam</p>
        </div>
      </div>

      {/* User List */}
      <div className="glass-card rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-white/5">
                <th className="text-left p-3 text-muted-foreground">Kullanıcı</th>
                <th className="text-left p-3 text-muted-foreground hidden sm:table-cell">ID</th>
                <th className="text-left p-3 text-muted-foreground hidden md:table-cell">IP</th>
                <th className="text-left p-3 text-muted-foreground">Üyelik</th>
                <th className="text-left p-3 text-muted-foreground hidden sm:table-cell">Durum</th>
                <th className="text-left p-3 text-muted-foreground hidden lg:table-cell">Kayıt</th>
                <th className="text-right p-3 text-muted-foreground">İşlem</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-neon-blue/10 flex items-center justify-center text-neon-blue text-[10px] font-bold shrink-0">{u.name[0]}</div>
                      <div>
                        <p className="font-medium text-xs">{u.name}</p>
                        <p className="text-[10px] text-muted-foreground">{u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-3 text-muted-foreground hidden sm:table-cell font-mono text-[10px]">{u.id.slice(0, 8)}</td>
                  <td className="p-3 text-muted-foreground hidden md:table-cell text-[10px]">{u.ip}</td>
                  <td className="p-3">
                    <span className={`px-1.5 py-0.5 rounded-full text-[10px] ${u.role === "VIP Premium" ? "bg-amber-500/10 text-amber-400" : u.role === "Pro" ? "bg-neon-purple/10 text-neon-purple" : "bg-white/10 text-muted-foreground"}`}>{u.role}</span>
                  </td>
                  <td className="p-3 hidden sm:table-cell">
                    <span className={`px-1.5 py-0.5 rounded-full text-[10px] ${u.status === "active" ? "bg-green-500/10 text-green-400" : u.status === "banned" ? "bg-red-500/10 text-red-400" : "bg-amber-500/10 text-amber-400"}`}>
                      {u.status === "active" ? "Aktif" : u.status === "banned" ? "Banlı" : "Pasif"}
                    </span>
                  </td>
                  <td className="p-3 text-muted-foreground hidden lg:table-cell text-[10px]">{new Date(u.createdAt).toLocaleString("tr-TR")}</td>
                  <td className="p-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => handleAddCredits(u.id)} title="Kredi Yükle" className="p-1 rounded hover:bg-white/10 text-neon-blue"><Coins size={12} /></button>
                      <button onClick={() => handleGiveVip(u.id)} title="VIP Ver" className="p-1 rounded hover:bg-white/10 text-amber-400"><Crown size={12} /></button>
                      <button onClick={() => handleBan(u.id)} title="Banla" className="p-1 rounded hover:bg-white/10 text-red-400"><Ban size={12} /></button>
                    </div>
                  </td>
                </tr>
              ))}
              {users.length === 0 && (
                <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">Henüz kayıtlı kullanıcı yok</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ===== ADMIN MANAGEMENT =====
function AdminSection() {
  const admins = [
    { id: 1, name: "Ahmet Yılmaz", email: "ahmet@cortxgpt.com", role: "Süper Admin", status: "Aktif", lastAction: "Kredi yükleme" },
    { id: 2, name: "Elif Demir", email: "elif@cortxgpt.com", role: "Moderatör", status: "Aktif", lastAction: "Kullanıcı ban" },
    { id: 3, name: "Can Kaya", email: "can@cortxgpt.com", role: "Admin", status: "Pasif", lastAction: "Paket düzenleme" },
  ];
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold font-[var(--font-heading)]">Admin Listesi</h3>
        <button onClick={() => toast.success("Yeni admin ekleme formu açıldı")} className="gradient-btn px-3 py-1.5 rounded-lg text-xs text-white flex items-center gap-1"><Plus size={12} /> Yeni Admin</button>
      </div>
      <div className="glass-card rounded-xl overflow-hidden">
        <table className="w-full text-xs">
          <thead><tr className="border-b border-white/5"><th className="text-left p-3 text-muted-foreground">Admin</th><th className="text-left p-3 text-muted-foreground">Rol</th><th className="text-left p-3 text-muted-foreground">Durum</th><th className="text-right p-3 text-muted-foreground">İşlem</th></tr></thead>
          <tbody>
            {admins.map((a) => (
              <tr key={a.id} className="border-b border-white/5 hover:bg-white/5">
                <td className="p-3"><p className="font-medium">{a.name}</p><p className="text-[10px] text-muted-foreground">{a.email}</p></td>
                <td className="p-3"><span className={`text-[10px] px-2 py-0.5 rounded-full ${a.role === "Süper Admin" ? "bg-amber-500/10 text-amber-400" : "bg-neon-blue/10 text-neon-blue"}`}>{a.role}</span></td>
                <td className="p-3"><span className={`text-[10px] px-2 py-0.5 rounded-full ${a.status === "Aktif" ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400"}`}>{a.status}</span></td>
                <td className="p-3 text-right"><button onClick={() => toast.info("Düzenleme")} className="p-1 rounded hover:bg-white/10 text-muted-foreground"><Edit size={12} /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ===== PACKAGE SECTION =====
function PackageSection() {
  const packages = [
    { id: 1, name: "Free", price: "₺0", credits: 100, dailyCredits: 50 },
    { id: 2, name: "Pro", price: "₺149", credits: 1000, dailyCredits: 300 },
    { id: 3, name: "VIP Premium", price: "₺349", credits: 3000, dailyCredits: 500 },
  ];
  return (
    <div className="space-y-4">
      <h3 className="font-semibold font-[var(--font-heading)]">Paket Yönetimi</h3>
      <div className="grid md:grid-cols-3 gap-4">
        {packages.map((p) => (
          <div key={p.id} className={`glass-card rounded-xl p-5 ${p.name === "VIP Premium" ? "border-amber-500/30" : ""}`}>
            <div className="flex items-center gap-2 mb-3">{p.name === "VIP Premium" && <Crown size={14} className="text-amber-400" />}<h4 className="font-semibold">{p.name}</h4></div>
            <p className="text-2xl font-bold mb-3">{p.price}<span className="text-xs text-muted-foreground">/ay</span></p>
            <div className="space-y-2 text-xs text-muted-foreground">
              <div className="flex justify-between"><span>Başlangıç</span><span className="text-foreground">{p.credits}</span></div>
              <div className="flex justify-between"><span>Günlük</span><span className="text-foreground">{p.dailyCredits}</span></div>
            </div>
            <button onClick={() => toast.info("Düzenleme modu")} className="mt-3 w-full py-1.5 rounded-lg border border-white/10 text-xs hover:bg-white/5">Düzenle</button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ===== CREDIT SECTION =====
function CreditSection() {
  return (
    <div className="space-y-4">
      <h3 className="font-semibold font-[var(--font-heading)]">Kredi Sistemi</h3>
      <div className="glass-card rounded-xl p-5 border-amber-500/20">
        <div className="flex items-center gap-2 mb-4"><Crown size={16} className="text-amber-400" /><h4 className="font-semibold">VIP Kredi Ayarları</h4></div>
        <div className="grid sm:grid-cols-3 gap-4">
          {[["VIP Başlangıç", 3000], ["VIP Günlük", 500], ["VIP Süre (Gün)", 30]].map(([l, v]) => (
            <div key={l as string}><label className="text-xs text-muted-foreground mb-1 block">{l as string}</label><input type="number" defaultValue={v as number} className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm outline-none focus:border-neon-blue/50" /></div>
          ))}
        </div>
      </div>
      <div className="glass-card rounded-xl p-5">
        <h4 className="font-semibold mb-4">Genel Kredi Ayarları</h4>
        <div className="grid sm:grid-cols-3 gap-4">
          {[["Free Günlük", 100], ["Pro Günlük", 300], ["İşlem Başı", 7]].map(([l, v]) => (
            <div key={l as string}><label className="text-xs text-muted-foreground mb-1 block">{l as string}</label><input type="number" defaultValue={v as number} className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm outline-none focus:border-neon-blue/50" /></div>
          ))}
        </div>
        <button onClick={() => toast.success("Ayarlar kaydedildi")} className="mt-4 gradient-btn px-4 py-2 rounded-lg text-sm text-white flex items-center gap-2"><Save size={14} /> Kaydet</button>
      </div>
    </div>
  );
}

// ===== SIMPLE SECTIONS =====
function PermissionsSection() {
  const roles = [
    { name: "Süper Admin", perms: ["Tüm Yetkiler", "Kullanıcı Yönetimi", "Sistem Ayarları", "Kredi Yönetimi"] },
    { name: "Moderatör", perms: ["Kullanıcı Ban", "Destek Yönetimi", "Log Görüntüleme"] },
    { name: "Destek", perms: ["Canlı Destek", "Ticket Yönetimi"] },
  ];
  return (
    <div className="space-y-4">
      <h3 className="font-semibold font-[var(--font-heading)]">Yetki & Erişim</h3>
      <div className="grid md:grid-cols-3 gap-4">
        {roles.map((r) => (
          <div key={r.name} className="glass-card rounded-xl p-4">
            <h4 className="font-semibold mb-3">{r.name}</h4>
            <div className="space-y-2">{r.perms.map((p) => <div key={p} className="flex items-center gap-2 text-xs"><Check size={12} className="text-green-400" />{p}</div>)}</div>
            <button onClick={() => toast.info("Düzenleme")} className="mt-3 w-full py-1.5 rounded-lg border border-white/10 text-xs hover:bg-white/5">Düzenle</button>
          </div>
        ))}
      </div>
    </div>
  );
}

function SettingsSection() {
  return (
    <div className="space-y-4">
      <h3 className="font-semibold font-[var(--font-heading)]">Sistem Ayarları</h3>
      {[["Site Adı", "CortxGPT"], ["Site URL", "cortxgpt.com"], ["Destek E-posta", "destek@cortxgpt.com"]].map(([l, v]) => (
        <div key={l} className="glass-card rounded-xl p-4">
          <label className="text-xs text-muted-foreground mb-1 block">{l}</label>
          <input defaultValue={v} className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm outline-none focus:border-neon-blue/50" />
        </div>
      ))}
      <button onClick={() => toast.success("Ayarlar kaydedildi")} className="gradient-btn px-4 py-2 rounded-lg text-sm text-white flex items-center gap-2"><Save size={14} /> Kaydet</button>
    </div>
  );
}

function PaymentSection() {
  const payments = [
    { user: "ahmet@mail.com", plan: "Pro", amount: "₺149", date: "24.03.2026", status: "Başarılı" },
    { user: "elif@mail.com", plan: "VIP Premium", amount: "₺349", date: "24.03.2026", status: "Başarılı" },
    { user: "can@mail.com", plan: "Pro", amount: "₺149", date: "23.03.2026", status: "Başarısız" },
  ];
  return (
    <div className="space-y-4">
      <h3 className="font-semibold font-[var(--font-heading)]">Ödeme & Satış</h3>
      <div className="grid sm:grid-cols-3 gap-3">
        <StatCard icon={DollarSign} label="Bu Ay Gelir" value="₺187,200" change="+32%" color="bg-green-500/10 text-green-400" />
        <StatCard icon={Receipt} label="Toplam İşlem" value="1,847" color="bg-neon-blue/10 text-neon-blue" />
        <StatCard icon={TrendingUp} label="Başarı Oranı" value="%94.2" color="bg-neon-purple/10 text-neon-purple" />
      </div>
      <div className="glass-card rounded-xl overflow-hidden">
        <table className="w-full text-xs">
          <thead><tr className="border-b border-white/5"><th className="text-left p-3 text-muted-foreground">Kullanıcı</th><th className="text-left p-3 text-muted-foreground">Plan</th><th className="text-left p-3 text-muted-foreground">Tutar</th><th className="text-left p-3 text-muted-foreground">Durum</th></tr></thead>
          <tbody>{payments.map((p, i) => (
            <tr key={i} className="border-b border-white/5 hover:bg-white/5">
              <td className="p-3">{p.user}</td><td className="p-3">{p.plan}</td><td className="p-3">{p.amount}</td>
              <td className="p-3"><span className={`text-[10px] px-2 py-0.5 rounded-full ${p.status === "Başarılı" ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400"}`}>{p.status}</span></td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}

function UsersSection() {
  const [users, setUsers] = useState<RegisteredUser[]>(getRegisteredUsers());
  useEffect(() => { const iv = setInterval(() => setUsers(getRegisteredUsers()), 3000); return () => clearInterval(iv); }, []);
  return (
    <div className="space-y-4">
      <h3 className="font-semibold font-[var(--font-heading)]">Kullanıcı Yönetimi</h3>
      <div className="glass-card rounded-xl overflow-hidden">
        <table className="w-full text-xs">
          <thead><tr className="border-b border-white/5"><th className="text-left p-3 text-muted-foreground">Kullanıcı</th><th className="text-left p-3 text-muted-foreground">Rol</th><th className="text-left p-3 text-muted-foreground">Kredi</th><th className="text-left p-3 text-muted-foreground">Durum</th><th className="text-right p-3 text-muted-foreground">İşlem</th></tr></thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-b border-white/5 hover:bg-white/5">
                <td className="p-3"><p className="font-medium">{u.name}</p><p className="text-[10px] text-muted-foreground">{u.email}</p></td>
                <td className="p-3"><span className={`text-[10px] px-2 py-0.5 rounded-full ${u.role === "VIP Premium" ? "bg-amber-500/10 text-amber-400" : "bg-white/10 text-muted-foreground"}`}>{u.role}</span></td>
                <td className="p-3 font-mono">{u.credits}</td>
                <td className="p-3"><span className={`text-[10px] px-2 py-0.5 rounded-full ${u.status === "active" ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400"}`}>{u.status === "active" ? "Aktif" : "Banlı"}</span></td>
                <td className="p-3 text-right">
                  <div className="flex items-center justify-end gap-1">
                    <button onClick={() => { addCredits(u.id, 100); setUsers(getRegisteredUsers()); toast.success("100 kredi yüklendi"); }} className="p-1 rounded hover:bg-white/10 text-neon-blue"><Coins size={12} /></button>
                    <button onClick={() => { giveVip(u.id); setUsers(getRegisteredUsers()); toast.success("VIP verildi"); }} className="p-1 rounded hover:bg-white/10 text-amber-400"><Crown size={12} /></button>
                    <button onClick={() => { banUser(u.id); setUsers(getRegisteredUsers()); toast.error("Banlandı"); }} className="p-1 rounded hover:bg-white/10 text-red-400"><Ban size={12} /></button>
                  </div>
                </td>
              </tr>
            ))}
            {users.length === 0 && <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">Kullanıcı yok</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function LogsSection() {
  const [notifs, setNotifs] = useState<AdminNotification[]>(getNotifications());
  useEffect(() => { const iv = setInterval(() => setNotifs(getNotifications()), 2000); return () => clearInterval(iv); }, []);
  return (
    <div className="space-y-4">
      <h3 className="font-semibold font-[var(--font-heading)]">Log & Güvenlik</h3>
      <div className="glass-card rounded-xl overflow-hidden">
        <div className="max-h-[500px] overflow-y-auto scrollbar-thin">
          {notifs.map((n) => (
            <div key={n.id} className="flex items-start gap-3 p-3 border-b border-white/5 hover:bg-white/5">
              <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${n.type === "new_user" ? "bg-cyan-500/10 text-cyan-400" : n.type === "support_request" ? "bg-amber-500/10 text-amber-400" : n.type === "vip_purchase" ? "bg-neon-purple/10 text-neon-purple" : "bg-neon-blue/10 text-neon-blue"}`}>
                {n.type === "new_user" ? <UserPlus size={12} /> : n.type === "support_request" ? <Headphones size={12} /> : n.type === "vip_purchase" ? <Crown size={12} /> : <Bell size={12} />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium">{n.title}</p>
                <p className="text-[10px] text-muted-foreground truncate">{n.message}</p>
              </div>
              <span className="text-[9px] text-muted-foreground shrink-0">{new Date(n.time).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })}</span>
            </div>
          ))}
          {notifs.length === 0 && <div className="p-8 text-center text-muted-foreground text-sm">Log kaydı yok</div>}
        </div>
      </div>
    </div>
  );
}

function NotificationsSection() {
  const [notifs, setNotifs] = useState<AdminNotification[]>(getNotifications());
  useEffect(() => { const iv = setInterval(() => setNotifs(getNotifications()), 2000); return () => clearInterval(iv); }, []);
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold font-[var(--font-heading)]">Bildirimler</h3>
        <button onClick={() => { markAllRead(); setNotifs(getNotifications()); toast.success("Tümü okundu"); }} className="text-xs text-neon-blue hover:underline">Tümünü Okundu İşaretle</button>
      </div>
      <div className="space-y-2">
        {notifs.slice(0, 20).map((n) => (
          <div key={n.id} className={`glass-card rounded-xl p-3 flex items-start gap-3 ${!n.read ? "border-neon-blue/20" : ""}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${n.type === "new_user" ? "bg-cyan-500/10 text-cyan-400" : n.type === "support_request" ? "bg-amber-500/10 text-amber-400" : "bg-neon-blue/10 text-neon-blue"}`}>
              {n.type === "new_user" ? <UserPlus size={14} /> : n.type === "support_request" ? <Headphones size={14} /> : <Bell size={14} />}
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">{n.title}</p>
              <p className="text-xs text-muted-foreground">{n.message}</p>
              <p className="text-[10px] text-muted-foreground mt-1">{new Date(n.time).toLocaleString("tr-TR")}</p>
            </div>
            {!n.read && <span className="w-2 h-2 rounded-full bg-neon-blue shrink-0 mt-2" />}
          </div>
        ))}
      </div>
    </div>
  );
}

function ExtrasSection() {
  return (
    <div className="space-y-4">
      <h3 className="font-semibold font-[var(--font-heading)]">Ekstra Araçlar</h3>
      <div className="grid sm:grid-cols-2 gap-4">
        {[
          { icon: Download, title: "Veri Dışa Aktar", desc: "Kullanıcı ve log verilerini dışa aktar" },
          { icon: RefreshCw, title: "Önbellek Temizle", desc: "Sistem önbelleğini temizle" },
          { icon: Globe, title: "API Ayarları", desc: "API anahtarları ve endpoint yönetimi" },
          { icon: Shield, title: "Güvenlik Taraması", desc: "Sistem güvenlik kontrolü başlat" },
        ].map((t) => (
          <div key={t.title} className="glass-card rounded-xl p-4 glass-card-hover cursor-pointer" onClick={() => toast.info(`${t.title} çalıştırıldı`)}>
            <t.icon size={20} className="text-neon-blue mb-2" />
            <h4 className="text-sm font-semibold">{t.title}</h4>
            <p className="text-xs text-muted-foreground">{t.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ===== MAIN FOUNDER PANEL =====
export default function FounderPanel() {
  const [activeSection, setActiveSection] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [, navigate] = useLocation();
  const [unreadCount, setUnreadCount] = useState(getUnreadCount());
  const [waitingCount, setWaitingCount] = useState(getWaitingTickets().length);

  const adminSession = (() => {
    try { return JSON.parse(localStorage.getItem("cortxgpt_admin_session") || "null"); } catch { return null; }
  })();

  useEffect(() => {
    if (!adminSession?.isAdmin) { navigate("/admin"); return; }
    const iv = setInterval(() => {
      setUnreadCount(getUnreadCount());
      setWaitingCount(getWaitingTickets().length);
    }, 2000);
    return () => clearInterval(iv);
  }, [adminSession, navigate]);

  if (!adminSession?.isAdmin) return null;

  const renderSection = () => {
    switch (activeSection) {
      case "dashboard": return <DashboardSection />;
      case "live-support": return <LiveSupportSection />;
      case "registrations": return <RegistrationsSection />;
      case "admins": return <AdminSection />;
      case "packages": return <PackageSection />;
      case "credits": return <CreditSection />;
      case "permissions": return <PermissionsSection />;
      case "settings": return <SettingsSection />;
      case "payments": return <PaymentSection />;
      case "users": return <UsersSection />;
      case "logs": return <LogsSection />;
      case "notifications": return <NotificationsSection />;
      case "extras": return <ExtrasSection />;
      default: return <DashboardSection />;
    }
  };

  return (
    <div className="h-screen flex bg-background overflow-hidden">
      {sidebarOpen && <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-40 w-60 bg-[oklch(0.08_0.012_270)] border-r border-white/5 flex flex-col transition-transform duration-300 ${sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}>
        <div className="p-3 border-b border-white/5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <img src={LOGO_URL} alt="CortxGPT" className="w-6 h-6" />
              <span className="text-sm font-bold gradient-text font-[var(--font-heading)]">Kurucu Panel</span>
            </div>
            <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-1 text-muted-foreground"><X size={16} /></button>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto scrollbar-thin p-2 space-y-0.5">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => { setActiveSection(item.id); setSidebarOpen(false); }}
              className={`w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg text-xs transition-colors ${activeSection === item.id ? "bg-neon-blue/10 text-neon-blue" : "text-muted-foreground hover:bg-white/5 hover:text-foreground"}`}
            >
              <div className="flex items-center gap-2"><item.icon size={14} />{item.label}</div>
              {item.id === "live-support" && waitingCount > 0 && <span className="w-4 h-4 rounded-full bg-red-500 text-white text-[9px] flex items-center justify-center font-bold animate-pulse">{waitingCount}</span>}
              {item.id === "notifications" && unreadCount > 0 && <span className="w-4 h-4 rounded-full bg-neon-blue text-white text-[9px] flex items-center justify-center font-bold">{unreadCount}</span>}
            </button>
          ))}
        </nav>

        <div className="p-3 border-t border-white/5 space-y-1">
          <Link href="/" className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors px-3 py-2"><ArrowLeft size={12} /> Ana Sayfa</Link>
          <button onClick={() => { localStorage.removeItem("cortxgpt_admin_session"); toast.info("Çıkış yapıldı"); navigate("/admin"); }} className="w-full flex items-center gap-2 text-xs text-red-400 hover:text-red-300 transition-colors px-3 py-2 rounded-lg hover:bg-red-500/10"><LogOut size={12} /> Çıkış Yap</button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-12 flex items-center justify-between px-4 border-b border-white/5 shrink-0 glass-card">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-1 text-muted-foreground"><Menu size={18} /></button>
            <h2 className="text-xs font-semibold font-[var(--font-heading)]">{menuItems.find((m) => m.id === activeSection)?.label || "Dashboard"}</h2>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setActiveSection("notifications")} className="relative p-1.5 rounded-lg hover:bg-white/5 text-muted-foreground">
              <Bell size={16} />
              {unreadCount > 0 && <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-red-500 text-white text-[8px] flex items-center justify-center font-bold">{unreadCount}</span>}
            </button>
            <div className="flex items-center gap-2 px-2 py-1 rounded-lg bg-amber-500/10 text-amber-400 text-[10px]"><Crown size={10} /> Kurucu</div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto scrollbar-thin p-4">
          <motion.div key={activeSection} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2 }}>
            {renderSection()}
          </motion.div>
        </div>
      </main>
    </div>
  );
}
