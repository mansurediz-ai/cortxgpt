import { useState, useRef, useEffect } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  Send, Plus, Trash2, Copy, Menu, X, ArrowLeft, Bot, User,
  MessageSquare, MoreVertical, Check, Search
} from "lucide-react";
import { toast } from "sonner";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663469047697/7PMHtqMX2cLBqPHn4Fvif7/ai-brain-logo-UPKum59kVPznZdwMyoKdyZ.webp";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  time: string;
}

interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  createdAt: string;
}

const AI_RESPONSES = [
  "Merhaba! Size nasıl yardımcı olabilirim? CortxGPT olarak metin oluşturma, kod yazma, çeviri, analiz ve daha birçok konuda destek sunabilirim.",
  "Bu harika bir soru! Yapay zeka, makine öğrenimi algoritmalarını kullanarak verilerden öğrenir ve tahminlerde bulunur. Derin öğrenme ise sinir ağları kullanarak daha karmaşık kalıpları tespit edebilir.",
  "Elbette yardımcı olabilirim. İşte istediğiniz konuda detaylı bir açıklama:\n\nYapay zeka teknolojileri günümüzde sağlık, finans, eğitim ve daha birçok sektörde aktif olarak kullanılmaktadır. CortxGPT olarak en güncel AI modellerini kullanıyoruz.",
  "Tabii ki! Bu konuda size birkaç farklı yaklaşım önerebilirim. Her birinin kendine özgü avantajları var. Hangisini tercih edeceğiniz projenizin gereksinimlerine bağlı olacaktır.",
  "Anlıyorum. Bu konuyu detaylı bir şekilde ele alalım. CortxGPT'nin gelişmiş analiz yetenekleri sayesinde size kapsamlı bir değerlendirme sunabilirim.",
];

export default function Chat() {
  const [sessions, setSessions] = useState<ChatSession[]>([
    { id: "1", title: "Yeni Sohbet", messages: [], createdAt: new Date().toLocaleDateString("tr-TR") },
  ]);
  const [activeId, setActiveId] = useState("1");
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const activeSession = sessions.find((s) => s.id === activeId)!;

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeSession?.messages, isTyping]);

  const newChat = () => {
    const id = Date.now().toString();
    setSessions((prev) => [{ id, title: "Yeni Sohbet", messages: [], createdAt: new Date().toLocaleDateString("tr-TR") }, ...prev]);
    setActiveId(id);
    setSidebarOpen(false);
  };

  const deleteChat = (id: string) => {
    if (sessions.length <= 1) return;
    setSessions((prev) => prev.filter((s) => s.id !== id));
    if (activeId === id) setActiveId(sessions.find((s) => s.id !== id)!.id);
  };

  const copyMessage = (content: string, id: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    toast.success("Mesaj kopyalandı");
    setTimeout(() => setCopiedId(null), 2000);
  };

  const sendMessage = () => {
    if (!input.trim() || isTyping) return;
    const now = new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
    const userMsg: Message = { id: Date.now().toString(), role: "user", content: input.trim(), time: now };

    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeId
          ? { ...s, title: s.messages.length === 0 ? input.trim().slice(0, 30) + "..." : s.title, messages: [...s.messages, userMsg] }
          : s
      )
    );
    setInput("");
    setIsTyping(true);

    setTimeout(() => {
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: AI_RESPONSES[Math.floor(Math.random() * AI_RESPONSES.length)],
        time: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }),
      };
      setSessions((prev) => prev.map((s) => (s.id === activeId ? { ...s, messages: [...s.messages, aiMsg] } : s)));
      setIsTyping(false);
    }, 1500 + Math.random() * 1500);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="h-screen flex bg-background overflow-hidden">
      {/* Sidebar Overlay */}
      {sidebarOpen && <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-40 w-72 bg-[oklch(0.1_0.015_270)] border-r border-white/5 flex flex-col transition-transform duration-300 ${sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}>
        <div className="p-4 border-b border-white/5">
          <div className="flex items-center justify-between mb-4">
            <Link href="/" className="flex items-center gap-2">
              <img src={LOGO_URL} alt="CortxGPT" className="w-7 h-7" />
              <span className="text-lg font-bold gradient-text font-[var(--font-heading)]">CortxGPT</span>
            </Link>
            <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-1 text-muted-foreground"><X size={18} /></button>
          </div>
          <button onClick={newChat} className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border border-white/10 text-sm text-foreground hover:bg-white/5 transition-colors">
            <Plus size={16} /> Yeni Sohbet
          </button>
        </div>

        <div className="flex-1 overflow-y-auto scrollbar-thin p-3 space-y-1">
          {sessions.map((s) => (
            <div
              key={s.id}
              onClick={() => { setActiveId(s.id); setSidebarOpen(false); }}
              className={`group flex items-center gap-2 px-3 py-2.5 rounded-lg cursor-pointer transition-colors text-sm ${
                activeId === s.id ? "bg-white/10 text-foreground" : "text-muted-foreground hover:bg-white/5"
              }`}
            >
              <MessageSquare size={14} className="shrink-0" />
              <span className="flex-1 truncate">{s.title}</span>
              <button
                onClick={(e) => { e.stopPropagation(); deleteChat(s.id); }}
                className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-400 transition-all"
              >
                <Trash2 size={13} />
              </button>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-white/5">
          <Link href="/" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft size={14} /> Ana Sayfaya Dön
          </Link>
        </div>
      </aside>

      {/* Main Chat */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <div className="h-14 flex items-center justify-between px-4 border-b border-white/5 shrink-0">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-1.5 text-muted-foreground"><Menu size={20} /></button>
            <h2 className="text-sm font-medium truncate max-w-[200px] sm:max-w-none">{activeSession.title}</h2>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="hidden sm:inline">CortxGPT AI</span>
            <div className="w-2 h-2 rounded-full bg-green-400" />
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto scrollbar-thin">
          {activeSession.messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center p-6 text-center">
              <div className="w-16 h-16 rounded-2xl gradient-btn flex items-center justify-center mb-6">
                <Bot size={28} className="text-white" />
              </div>
              <h3 className="text-xl font-semibold font-[var(--font-heading)] mb-2">CortxGPT'ye Hoş Geldiniz</h3>
              <p className="text-sm text-muted-foreground max-w-md mb-8">Yapay zeka ile sohbet etmeye başlayın. Sorularınızı yazın, anında yanıt alın.</p>
              <div className="grid sm:grid-cols-2 gap-3 max-w-lg w-full">
                {["Yapay zeka nedir?", "Python ile web scraping", "İş planı oluştur", "Logo tasarım fikirleri"].map((q) => (
                  <button
                    key={q}
                    onClick={() => { setInput(q); inputRef.current?.focus(); }}
                    className="glass-card glass-card-hover rounded-xl px-4 py-3 text-sm text-left text-muted-foreground hover:text-foreground transition-all"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
              {activeSession.messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
                >
                  <div className={`w-8 h-8 rounded-lg shrink-0 flex items-center justify-center ${
                    msg.role === "user" ? "bg-neon-purple/20" : "gradient-btn"
                  }`}>
                    {msg.role === "user" ? <User size={14} className="text-neon-purple" /> : <Bot size={14} className="text-white" />}
                  </div>
                  <div className={`group max-w-[80%] ${msg.role === "user" ? "text-right" : ""}`}>
                    <div className={`inline-block px-4 py-3 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap ${
                      msg.role === "user"
                        ? "bg-neon-purple/20 text-foreground rounded-tr-md"
                        : "glass-card text-foreground rounded-tl-md"
                    }`}>
                      {msg.content}
                    </div>
                    <div className={`flex items-center gap-2 mt-1.5 ${msg.role === "user" ? "justify-end" : ""}`}>
                      <span className="text-[10px] text-muted-foreground">{msg.time}</span>
                      <button
                        onClick={() => copyMessage(msg.content, msg.id)}
                        className="opacity-0 group-hover:opacity-100 p-1 text-muted-foreground hover:text-foreground transition-all"
                      >
                        {copiedId === msg.id ? <Check size={12} className="text-green-400" /> : <Copy size={12} />}
                      </button>
                      {msg.role === "user" && (
                        <button
                          onClick={() => {
                            setSessions((prev) => prev.map((s) => s.id === activeId ? { ...s, messages: s.messages.filter((m) => m.id !== msg.id) } : s));
                          }}
                          className="opacity-0 group-hover:opacity-100 p-1 text-muted-foreground hover:text-red-400 transition-all"
                        >
                          <Trash2 size={12} />
                        </button>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}

              {isTyping && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-3">
                  <div className="w-8 h-8 rounded-lg gradient-btn flex items-center justify-center shrink-0">
                    <Bot size={14} className="text-white" />
                  </div>
                  <div className="glass-card rounded-2xl rounded-tl-md px-4 py-3">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs text-muted-foreground mr-1">AI yazıyor</span>
                      {[0, 1, 2].map((i) => (
                        <span key={i} className="w-1.5 h-1.5 rounded-full bg-neon-blue" style={{ animation: `typing-dot 1.4s ease-in-out ${i * 0.2}s infinite` }} />
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="shrink-0 border-t border-white/5 p-4">
          <div className="max-w-3xl mx-auto">
            <div className="flex items-end gap-3 glass-card rounded-2xl px-4 py-3">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Mesajınızı yazın..."
                rows={1}
                className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none resize-none max-h-32"
                style={{ minHeight: "24px" }}
              />
              <button
                onClick={sendMessage}
                disabled={!input.trim() || isTyping}
                className="p-2.5 rounded-xl gradient-btn text-white disabled:opacity-30 disabled:cursor-not-allowed shrink-0 transition-all"
              >
                <Send size={16} />
              </button>
            </div>
            <p className="text-[10px] text-muted-foreground text-center mt-2">
              CortxGPT hata yapabilir. Önemli bilgileri doğrulamanızı öneririz.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
